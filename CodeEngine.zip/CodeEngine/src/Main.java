
import codeengine.CodeEngine;
import codeengine.Editor;
import codeengine.Entity;
import codeengine.Game;
import codeengine.PlayerController;
import codeengine.SpriteRenderer;

import java.awt.Color;

public class Main extends Game {

    private Entity player;

    @Override
    public void create() {

        System.out.println("================================");
        System.out.println("        CodeEngine 0.1");
        System.out.println("================================");
        System.out.println("Игра создана!");

        // ========================================
        // PLAYER
        // ========================================

        player = new Entity("Player");

        player.setPosition(590, 310);
        player.setSize(100, 100);
        player.setColor(Color.WHITE);

        // ========================================
        // SPRITE RENDERER
        // ========================================

        SpriteRenderer spriteRenderer =
                new SpriteRenderer(Color.WHITE);

        player.addComponent(spriteRenderer);

        // ========================================
        // PLAYER CONTROLLER
        // ========================================

        PlayerController controller = new PlayerController();
        controller.setSpeed(250.0);

        player.addComponent(controller);

        getScene().add(player);

        // ========================================
        // GROUND
        // ========================================

        Entity ground = new Entity("Ground");

        ground.setPosition(400, 500);
        ground.setSize(400, 50);
        ground.setColor(Color.GREEN);

        getScene().add(ground);

        // ========================================
        // ENEMY
        // ========================================

        Entity enemy = new Entity("Enemy");

        enemy.setPosition(800, 300);
        enemy.setSize(50, 50);
        enemy.setColor(Color.RED);

        getScene().add(enemy);

        // ========================================
        // EDITOR
        // ========================================

        Editor editor = new Editor();

        editor.setGame(this);
        editor.setScene(getScene());
        editor.showEditor();
    }

    /**
     * Управление игроком теперь находится
     * в PlayerController.java.
     */
    @Override
    public void update(double deltaTime) {
        // Здесь можно будет разместить
        // общую игровую логику.
    }

    // ========================================
    // SCENE CHANGED
    // ========================================

    @Override
    public void onSceneChanged() {

        if (getScene() == null) {
            player = null;
            return;
        }

        player = getScene().find("Player");
    }

    // ========================================
    // MAIN
    // ========================================

    public static void main(String[] args) {
        CodeEngine.start(new Main());
    }
}
