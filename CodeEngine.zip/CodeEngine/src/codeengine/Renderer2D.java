package codeengine;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.image.BufferedImage;

public class Renderer2D {

    private Graphics2D graphics;

    public void begin(Graphics2D graphics) {
        this.graphics = graphics;
    }

    public void clear(Color color) {
        if (graphics == null) return;

        graphics.setColor(color);
        graphics.fillRect(
                0,
                0,
                graphics.getClipBounds().width,
                graphics.getClipBounds().height
        );
    }

    public void drawRect(
            int x,
            int y,
            int width,
            int height,
            Color color
    ) {
        if (graphics == null || color == null) return;

        graphics.setColor(color);
        graphics.fillRect(x, y, width, height);
    }

    public void drawImage(
            BufferedImage image,
            int x,
            int y,
            int width,
            int height
    ) {
        if (graphics == null || image == null) return;

        graphics.drawImage(
                image,
                x,
                y,
                Math.max(1, width),
                Math.max(1, height),
                null
        );
    }

    public void drawImage(
            Image image,
            int x,
            int y,
            int width,
            int height
    ) {
        if (graphics == null || image == null) return;

        graphics.drawImage(
                image,
                x,
                y,
                Math.max(1, width),
                Math.max(1, height),
                null
        );
    }

    public void drawOutline(
            int x,
            int y,
            int width,
            int height,
            Color color
    ) {
        if (graphics == null || color == null) return;

        graphics.setColor(color);
        graphics.drawRect(x, y, width, height);
    }

    public void end() {
        graphics = null;
    }
}