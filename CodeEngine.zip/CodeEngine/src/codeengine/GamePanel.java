package codeengine;

import javax.swing.JPanel;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;

public class GamePanel extends JPanel {

    private final Renderer2D renderer;
    private Scene scene;

    public GamePanel(Renderer2D renderer) {

        this.renderer = renderer;

        setFocusable(true);
        setDoubleBuffered(true);
        setBackground(Color.BLACK);
    }

    /**
     * Устанавливает сцену, которую нужно отображать.
     */
    public void setScene(Scene scene) {
        this.scene = scene;
    }

    /**
     * Возвращает текущую сцену.
     */
    public Scene getScene() {
        return scene;
    }

    @Override
    protected void paintComponent(Graphics graphics) {

        super.paintComponent(graphics);

        Graphics2D g2 = (Graphics2D) graphics;

        g2.setRenderingHint(
                RenderingHints.KEY_ANTIALIASING,
                RenderingHints.VALUE_ANTIALIAS_ON
        );

        renderer.begin(g2);

        // Очищаем экран
        renderer.clear(Color.BLACK);

        // Рисуем все объекты сцены
        if (scene != null) {
            scene.render(renderer);
        }

        renderer.end();
    }
}