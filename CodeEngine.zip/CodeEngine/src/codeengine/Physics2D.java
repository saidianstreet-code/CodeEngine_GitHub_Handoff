package codeengine;

import java.util.ArrayList;
import java.util.List;

/** Lightweight axis-aligned 2D physics for small games and prototypes. */
public final class Physics2D {
    public static final double GRAVITY = 980.0; // pixels per second squared
    private static final double MAX_STEP = 1.0 / 30.0;

    private Physics2D() { }

    public static void update(Scene scene, double deltaTime) {
        if (scene == null || !Double.isFinite(deltaTime) || deltaTime <= 0) return;
        // Substeps reduce tunnelling and make collisions more stable at low FPS.
        int steps = Math.max(1, Math.min(8, (int) Math.ceil(deltaTime / MAX_STEP)));
        double step = Math.min(deltaTime, MAX_STEP * 8) / steps;
        List<Entity> entities = new ArrayList<>(scene.getEntities());
        for (int i = 0; i < steps; i++) {
            for (Entity entity : entities) {
                if (entity == null || !entity.isActive()) continue;
                Rigidbody2D body = entity.getComponent(Rigidbody2D.class);
                BoxCollider2D collider = entity.getComponent(BoxCollider2D.class);
                if (body == null || !body.isEnabled() || body.getBodyType() != Rigidbody2D.BodyType.DYNAMIC) continue;

                if (body.isUseGravity()) {
                    body.setVelocityY(body.getVelocityY() + GRAVITY * body.getGravityScale() * step);
                }

                double dx = body.getVelocityX() * step;
                if (dx != 0) {
                    entity.setX(entity.getX() + dx);
                    if (collider != null && collider.isEnabled() && !collider.isTrigger()) {
                        for (Entity other : entities) {
                            if (other == entity || other == null || !other.isActive()) continue;
                            BoxCollider2D otherCollider = other.getComponent(BoxCollider2D.class);
                            if (otherCollider == null || !otherCollider.isEnabled() || otherCollider.isTrigger()) continue;
                            if (!overlaps(entity, collider, other, otherCollider)) continue;
                            if (dx > 0) entity.setX(other.getX() + otherCollider.getOffsetX() - collider.getOffsetX() - entity.getWidth());
                            else entity.setX(other.getX() + otherCollider.getOffsetX() + other.getWidth() - collider.getOffsetX());
                            body.setVelocityX(0);
                        }
                    }
                }

                double dy = body.getVelocityY() * step;
                if (dy != 0) {
                    entity.setY(entity.getY() + dy);
                    if (collider != null && collider.isEnabled() && !collider.isTrigger()) {
                        for (Entity other : entities) {
                            if (other == entity || other == null || !other.isActive()) continue;
                            BoxCollider2D otherCollider = other.getComponent(BoxCollider2D.class);
                            if (otherCollider == null || !otherCollider.isEnabled() || otherCollider.isTrigger()) continue;
                            if (!overlaps(entity, collider, other, otherCollider)) continue;
                            if (dy > 0) entity.setY(other.getY() + otherCollider.getOffsetY() - collider.getOffsetY() - entity.getHeight());
                            else entity.setY(other.getY() + otherCollider.getOffsetY() + other.getHeight() - collider.getOffsetY());
                            body.setVelocityY(0);
                        }
                    }
                }
            }
        }
    }

    private static boolean overlaps(Entity a, BoxCollider2D ca, Entity b, BoxCollider2D cb) {
        double ax1 = a.getX() + ca.getOffsetX();
        double ay1 = a.getY() + ca.getOffsetY();
        double ax2 = ax1 + a.getWidth();
        double ay2 = ay1 + a.getHeight();
        double bx1 = b.getX() + cb.getOffsetX();
        double by1 = b.getY() + cb.getOffsetY();
        double bx2 = bx1 + b.getWidth();
        double by2 = by1 + b.getHeight();
        return ax1 < bx2 && ax2 > bx1 && ay1 < by2 && ay2 > by1;
    }
}
