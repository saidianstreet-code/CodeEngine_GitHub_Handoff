package codeengine;

/** Axis-aligned rectangular collider matching its Entity's Transform size. */
public class BoxCollider2D extends Component {
    private double offsetX;
    private double offsetY;
    private boolean trigger;

    public double getOffsetX() { return offsetX; }
    public void setOffsetX(double offsetX) {
        if (Double.isFinite(offsetX)) this.offsetX = offsetX;
    }
    public double getOffsetY() { return offsetY; }
    public void setOffsetY(double offsetY) {
        if (Double.isFinite(offsetY)) this.offsetY = offsetY;
    }
    public boolean isTrigger() { return trigger; }
    public void setTrigger(boolean trigger) { this.trigger = trigger; }

    @Override public String toString() { return "BoxCollider2D"; }
}
