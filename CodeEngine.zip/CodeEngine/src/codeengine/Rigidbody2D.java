package codeengine;

/** Simple 2D rigid body. Positive Y points down, matching Swing screen coordinates. */
public class Rigidbody2D extends Component {
    public enum BodyType { STATIC, DYNAMIC }

    private BodyType bodyType = BodyType.DYNAMIC;
    private double mass = 1.0;
    private double gravityScale = 1.0;
    private double velocityX;
    private double velocityY;
    private boolean useGravity = true;

    public BodyType getBodyType() { return bodyType; }
    public void setBodyType(BodyType bodyType) {
        if (bodyType != null) this.bodyType = bodyType;
        if (this.bodyType == BodyType.STATIC) {
            velocityX = 0;
            velocityY = 0;
        }
    }

    public double getMass() { return mass; }
    public void setMass(double mass) {
        if (Double.isFinite(mass) && mass > 0) this.mass = mass;
    }

    public double getGravityScale() { return gravityScale; }
    public void setGravityScale(double gravityScale) {
        if (Double.isFinite(gravityScale)) this.gravityScale = Math.max(-20, Math.min(20, gravityScale));
    }

    public double getVelocityX() { return velocityX; }
    public double getVelocityY() { return velocityY; }
    public void setVelocity(double x, double y) {
        if (bodyType == BodyType.DYNAMIC) {
            velocityX = Double.isFinite(x) ? x : 0;
            velocityY = Double.isFinite(y) ? y : 0;
        }
    }
    public void setVelocityX(double x) { setVelocity(x, velocityY); }
    public void setVelocityY(double y) { setVelocity(velocityX, y); }

    public boolean isUseGravity() { return useGravity; }
    public void setUseGravity(boolean useGravity) { this.useGravity = useGravity; }

    @Override public void update(double deltaTime) { /* Stepped by Physics2D through Scene. */ }
    @Override public String toString() { return "Rigidbody2D"; }
}
