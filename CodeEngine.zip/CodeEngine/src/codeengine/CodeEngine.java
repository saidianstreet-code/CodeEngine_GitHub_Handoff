package codeengine;

public class CodeEngine {

    private static Game game;

    public static void start(Game gameInstance) {
        game = gameInstance;

        game.startEngine();
    }

    public static Game getGame() {
        return game;
    }
}