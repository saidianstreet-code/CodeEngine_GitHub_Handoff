package codeengine;

import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;

public class Mouse implements MouseListener, MouseMotionListener {

    private static final Mouse instance = new Mouse();

    private int x;
    private int y;

    private int screenX;
    private int screenY;

    private final boolean[] buttons = new boolean[10];
    private final boolean[] pressed = new boolean[10];
    private final boolean[] released = new boolean[10];

    private Mouse() {
    }

    public static Mouse getInstance() {
        return instance;
    }

    @Override
    public void mousePressed(MouseEvent e) {

        int button = e.getButton();

        if (button >= 0 && button < instance.buttons.length) {

            if (!instance.buttons[button]) {
                instance.pressed[button] = true;
            }

            instance.buttons[button] = true;
        }

        updatePosition(e);
    }

    @Override
    public void mouseReleased(MouseEvent e) {

        int button = e.getButton();

        if (button >= 0 && button < instance.buttons.length) {

            instance.buttons[button] = false;
            instance.released[button] = true;
        }

        updatePosition(e);
    }

    @Override
    public void mouseMoved(MouseEvent e) {
        updatePosition(e);
    }

    @Override
    public void mouseDragged(MouseEvent e) {
        updatePosition(e);
    }

    private void updatePosition(MouseEvent e) {

        instance.x = e.getX();
        instance.y = e.getY();

        instance.screenX = e.getXOnScreen();
        instance.screenY = e.getYOnScreen();
    }

    /**
     * Проверяет, удерживается ли кнопка мыши.
     *
     * 1 = левая кнопка
     * 2 = средняя кнопка
     * 3 = правая кнопка
     */
    public static boolean isButtonDown(int button) {

        return button >= 0
                && button < instance.buttons.length
                && instance.buttons[button];
    }

    /**
     * Проверяет нажатие кнопки мыши
     * в текущем кадре.
     */
    public static boolean isButtonPressed(int button) {

        return button >= 0
                && button < instance.pressed.length
                && instance.pressed[button];
    }

    /**
     * Проверяет отпускание кнопки мыши
     * в текущем кадре.
     */
    public static boolean isButtonReleased(int button) {

        return button >= 0
                && button < instance.released.length
                && instance.released[button];
    }

    /**
     * X курсора относительно игрового окна.
     */
    public static int getX() {
        return instance.x;
    }

    /**
     * Y курсора относительно игрового окна.
     */
    public static int getY() {
        return instance.y;
    }

    /**
     * X курсора относительно всего экрана.
     */
    public static int getScreenX() {
        return instance.screenX;
    }

    /**
     * Y курсора относительно всего экрана.
     */
    public static int getScreenY() {
        return instance.screenY;
    }

    /**
     * Очищает состояния pressed/released
     * после обработки текущего кадра.
     */
    public static void update() {

        for (int i = 0; i < instance.pressed.length; i++) {
            instance.pressed[i] = false;
            instance.released[i] = false;
        }
    }

    @Override
    public void mouseClicked(MouseEvent e) {
        updatePosition(e);
    }

    @Override
    public void mouseEntered(MouseEvent e) {
        updatePosition(e);
    }

    @Override
    public void mouseExited(MouseEvent e) {
        updatePosition(e);
    }
}