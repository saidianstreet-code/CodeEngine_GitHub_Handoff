
package codeengine;

import java.awt.Color;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;

public class SpriteRenderer extends Component {

    private Color color = Color.WHITE;
    private boolean visible = true;
    private BufferedImage texture;
    private String texturePath = "";

    public SpriteRenderer() {
        this(Color.WHITE);
    }

    // Для совместимости с Main.java
    public SpriteRenderer(Color color) {
        setColor(color);
    }

    public void render(Renderer2D renderer) {
        if (!isEnabled() || !visible || renderer == null) {
            return;
        }

        Entity entity = getEntity();

        if (entity == null || !entity.isVisible()) {
            return;
        }

        int x = (int) entity.getX();
        int y = (int) entity.getY();
        int width = (int) entity.getWidth();
        int height = (int) entity.getHeight();

        if (texture != null) {
            renderer.drawImage(texture, x, y, width, height);
        } else {
            // Резервное отображение, если текстура не назначена.
            renderer.drawRect(x, y, width, height, color);
        }
    }

    public boolean loadTexture(String path) {
        if (path == null || path.trim().isEmpty()) {
            return false;
        }

        try {
            BufferedImage loaded = ImageIO.read(new File(path));

            if (loaded == null) {
                System.err.println(
                    "CodeEngine: неподдерживаемый формат: " + path
                );
                return false;
            }

            texture = loaded;
            texturePath = path;
            return true;

        } catch (IOException exception) {
            System.err.println(
                "CodeEngine: не удалось загрузить текстуру: " + path
            );
            exception.printStackTrace();
            return false;
        }
    }

    public void clearTexture() {
        texture = null;
        texturePath = "";
    }

    public BufferedImage getTexture() {
        return texture;
    }

    public String getTexturePath() {
        return texturePath;
    }

    public Color getColor() {
        return color;
    }

    public void setColor(Color color) {
        if (color != null) {
            this.color = color;
        }
    }

    public boolean isVisible() {
        return visible;
    }

    public void setVisible(boolean visible) {
        this.visible = visible;
    }

    @Override
    public String toString() {
        return "SpriteRenderer";
    }
}
