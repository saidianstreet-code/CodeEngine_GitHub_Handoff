
package codeengine;

import javax.swing.*;

import javax.swing.border.EmptyBorder;
import java.awt.*;

public class HierarchyPanel extends JPanel {

    private final DefaultListModel<Entity> listModel;
    private final JList<Entity> list;
    private final JLabel countLabel;

    private Scene scene;

    private static final Color PANEL =
            new Color(30, 32, 37);
    private static final Color HEADER =
            new Color(35, 37, 43);
    private static final Color BORDER =
            new Color(53, 56, 64);
    private static final Color TEXT =
            new Color(224, 227, 235);
    private static final Color MUTED =
            new Color(140, 146, 160);
    private static final Color ACCENT =
            new Color(75, 135, 235);

    public HierarchyPanel() {
        setLayout(new BorderLayout());
        setPreferredSize(new Dimension(230, 0));
        setMinimumSize(new Dimension(175, 0));
        setBackground(PANEL);

        setBorder(BorderFactory.createMatteBorder(
                0, 0, 0, 1, BORDER
        ));

        // HEADER
        JPanel header = new JPanel(new BorderLayout(8, 0));
        header.setBackground(HEADER);
        header.setBorder(new EmptyBorder(12, 13, 12, 12));

        JLabel title = new JLabel("HIERARCHY");
        title.setForeground(TEXT);
        title.setFont(new Font("SansSerif", Font.BOLD, 12));

        countLabel = new JLabel("0");
        countLabel.setForeground(MUTED);
        countLabel.setFont(new Font("SansSerif", Font.PLAIN, 11));
        countLabel.setHorizontalAlignment(SwingConstants.RIGHT);

        header.add(title, BorderLayout.CENTER);
        header.add(countLabel, BorderLayout.EAST);

        add(header, BorderLayout.NORTH);

        // OBJECT LIST
        listModel = new DefaultListModel<>();
        list = new JList<>(listModel);

        list.setBackground(PANEL);
        list.setForeground(TEXT);
        list.setSelectionBackground(new Color(45, 77, 125));
        list.setSelectionForeground(Color.WHITE);
        list.setFont(new Font("SansSerif", Font.PLAIN, 13));
        list.setFixedCellHeight(32);
        list.setBorder(new EmptyBorder(5, 5, 5, 5));
        list.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        list.setFocusable(true);
        list.setCellRenderer(new EntityRenderer());

        JScrollPane scroll = new JScrollPane(list);
        scroll.setBorder(BorderFactory.createEmptyBorder());
        scroll.setBackground(PANEL);
        scroll.getViewport().setBackground(PANEL);
        scroll.getVerticalScrollBar().setUnitIncrement(14);

        scroll.getVerticalScrollBar().setUI(
                new javax.swing.plaf.basic.BasicScrollBarUI() {
                    @Override
                    protected void configureScrollBarColors() {
                        thumbColor = new Color(75, 79, 91);
                        trackColor = PANEL;
                    }

                    @Override
                    protected JButton createDecreaseButton(int orientation) {
                        return zeroButton();
                    }

                    @Override
                    protected JButton createIncreaseButton(int orientation) {
                        return zeroButton();
                    }

                    private JButton zeroButton() {
                        JButton button = new JButton();
                        button.setPreferredSize(new Dimension(0, 0));
                        button.setMinimumSize(new Dimension(0, 0));
                        button.setMaximumSize(new Dimension(0, 0));
                        return button;
                    }
                }
        );

        add(scroll, BorderLayout.CENTER);

        updateCount();
    }

    private class EntityRenderer extends DefaultListCellRenderer {
        @Override
        public java.awt.Component getListCellRendererComponent(
                JList<?> source,
                Object value,
                int index,
                boolean selected,
                boolean focused) {

            JLabel label = (JLabel) super.getListCellRendererComponent(
                    source, value, index, selected, focused
            );

            label.setOpaque(true);
            label.setBorder(new EmptyBorder(0, 8, 0, 8));
            label.setFont(new Font("SansSerif", Font.PLAIN, 13));

            if (value instanceof Entity) {
                Entity entity = (Entity) value;
                label.setText("  ◆   " + entity.getName());
                label.setToolTipText(entity.getName());
            }

            if (selected) {
                label.setBackground(new Color(45, 77, 125));
                label.setForeground(Color.WHITE);
            } else {
                label.setBackground(PANEL);
                label.setForeground(TEXT);
            }

            return label;
        }
    }

    public void setScene(Scene scene) {
        this.scene = scene;
        refresh();
    }

    public void refresh() {
        Entity selected = list.getSelectedValue();

        listModel.clear();

        if (scene != null) {
            for (Entity entity : scene.getEntities()) {
                listModel.addElement(entity);
            }
        }

        updateCount();

        if (selected != null) {
            list.setSelectedValue(selected, true);
        }

        list.repaint();
    }

    private void updateCount() {
        int count = listModel.size();
        countLabel.setText(
                count + (count == 1 ? " object" : " objects")
        );
    }

    public JList<Entity> getList() {
        return list;
    }

    public void selectEntity(Entity entity) {
        if (entity == null) {
            clearSelection();
            return;
        }

        list.setSelectedValue(entity, true);
    }

    public void clearSelection() {
        list.clearSelection();
    }

    public Entity getSelectedEntity() {
        return list.getSelectedValue();
    }
}
