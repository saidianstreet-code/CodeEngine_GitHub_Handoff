package codeengine;

public class Camera2D {

    private double x;
    private double y;

    private double zoom = 1.0;

    public Camera2D() {
    }

    public Camera2D(double x, double y) {
        this.x = x;
        this.y = y;
    }

    public double getX() {
        return x;
    }

    public double getY() {
        return y;
    }

    public void setPosition(
            double x,
            double y
    ) {
        this.x = x;
        this.y = y;
    }

    public void move(
            double dx,
            double dy
    ) {
        x += dx;
        y += dy;
    }

    public double getZoom() {
        return zoom;
    }

    public void setZoom(
            double zoom
    ) {

        if (zoom <= 0) {
            zoom = 0.01;
        }

        this.zoom = zoom;
    }

    public void zoom(
            double amount
    ) {
        setZoom(zoom + amount);
    }

    /**
     * Преобразует мировую X
     * в координату экрана.
     */
    public double worldToScreenX(
            double worldX,
            int screenWidth
    ) {

        return (
                worldX - x
        ) * zoom
                + screenWidth / 2.0;
    }

    /**
     * Преобразует мировую Y
     * в координату экрана.
     */
    public double worldToScreenY(
            double worldY,
            int screenHeight
    ) {

        return (
                worldY - y
        ) * zoom
                + screenHeight / 2.0;
    }

    /**
     * Преобразует экранную X
     * обратно в мировую.
     */
    public double screenToWorldX(
            double screenX,
            int screenWidth
    ) {

        return (
                screenX - screenWidth / 2.0
        ) / zoom + x;
    }

    /**
     * Преобразует экранную Y
     * обратно в мировую.
     */
    public double screenToWorldY(
            double screenY,
            int screenHeight
    ) {

        return (
                screenY - screenHeight / 2.0
        ) / zoom + y;
    }
}