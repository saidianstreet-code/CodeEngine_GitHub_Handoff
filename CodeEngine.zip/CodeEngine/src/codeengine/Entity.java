package codeengine;

import java.awt.Color;
import java.util.ArrayList;
import java.util.List;

public class Entity {
    private String name;
    private final Transform transform;
    private Color color = Color.WHITE;
    private boolean visible = true;
    private boolean active = true;
    private final List<Component> components = new ArrayList<>();

    public Entity(String name) {
        this.name = name;
        transform = new Transform();
        transform.onAttach(this);
        components.add(transform);
    }

    public void update(double deltaTime) {
        if (!active) return;
        for (Component component : new ArrayList<>(components)) {
            if (component != null && component.isEnabled()) component.update(deltaTime);
        }
    }

    public void render(Renderer2D renderer) {
        if (!visible || renderer == null) return;

        ColorRenderer colorRenderer = getComponent(ColorRenderer.class);
        SpriteRenderer spriteRenderer = getComponent(SpriteRenderer.class);

        if (colorRenderer != null) {
            colorRenderer.render(renderer);
        } else if (spriteRenderer == null || spriteRenderer.getTexture() == null) {
            renderer.drawRect((int) getX(), (int) getY(), (int) getWidth(),
                    (int) getHeight(), color);
        }

        if (spriteRenderer != null && spriteRenderer.getTexture() != null) {
            spriteRenderer.render(renderer);
        }
    }

    public String getName() { return name; }
    public void setName(String name) { if (name != null) this.name = name; }
    public Transform getTransform() { return transform; }
    public double getX() { return transform.getX(); }
    public double getY() { return transform.getY(); }
    public void setPosition(double x, double y) { transform.setPosition(x, y); }
    public void setX(double x) { transform.setPosition(x, getY()); }
    public void setY(double y) { transform.setPosition(getX(), y); }
    public void move(double dx, double dy) { transform.move(dx, dy); }
    public double getWidth() { return transform.getWidth(); }
    public double getHeight() { return transform.getHeight(); }
    public void setSize(double width, double height) {
        transform.setSize(Math.max(1, width), Math.max(1, height));
    }
    public void setWidth(double width) { setSize(width, getHeight()); }
    public void setHeight(double height) { setSize(getWidth(), height); }
    public Color getColor() { return color; }
    public void setColor(Color color) { if (color != null) this.color = color; }
    public boolean isVisible() { return visible; }
    public void setVisible(boolean visible) { this.visible = visible; }
    public boolean isActive() { return active; }
    public void setActive(boolean active) { this.active = active; }

    public void addComponent(Component component) {
        if (component == null || components.contains(component) || component instanceof Transform) return;
        components.add(component);
        component.onAttach(this);
    }

    public void removeComponent(Component component) {
        if (component == null || component == transform) return;
        if (components.remove(component)) component.onDetach();
    }

    public List<Component> getComponents() { return new ArrayList<>(components); }

    public <T extends Component> T getComponent(Class<T> type) {
        if (type == null) return null;
        for (Component component : components) {
            if (type.isInstance(component)) return type.cast(component);
        }
        return null;
    }

    public boolean hasComponent(Class<? extends Component> type) {
        return getComponent(type) != null;
    }

    public boolean contains(double worldX, double worldY) {
        return worldX >= getX() && worldX <= getX() + getWidth()
                && worldY >= getY() && worldY <= getY() + getHeight();
    }

    @Override public String toString() { return name; }
}
