package codeengine;

/**
 * Базовый класс всех компонентов CodeEngine.
 *
 * Компонент позволяет добавлять Entity
 * отдельное поведение или функциональность.
 */
public abstract class Component {

    private Entity entity;

    private boolean enabled = true;

    /**
     * Вызывается после добавления компонента
     * к Entity.
     */
    public void onAttach(Entity entity) {

        this.entity = entity;
    }

    /**
     * Вызывается перед удалением компонента
     * из Entity.
     */
    public void onDetach() {

        this.entity = null;
    }

    /**
     * Игровое обновление компонента.
     */
    public void update(double deltaTime) {
    }

    /**
     * Получить Entity,
     * которому принадлежит компонент.
     */
    public Entity getEntity() {

        return entity;
    }

    /**
     * Проверить, включён ли компонент.
     */
    public boolean isEnabled() {

        return enabled;
    }

    /**
     * Включить или выключить компонент.
     */
    public void setEnabled(
            boolean enabled
    ) {

        this.enabled = enabled;
    }
}