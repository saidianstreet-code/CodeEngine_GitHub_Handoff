
package codeengine;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.filechooser.FileNameExtensionFilter;
import java.awt.*;
import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.Transferable;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.function.Consumer;

public class FilePanel extends JPanel {

    private final DefaultListModel<File> model =
            new DefaultListModel<>();

    private final JList<File> list = new JList<>(model);
    private final JTextField pathField = new JTextField();

    private File projectDirectory;
    private File currentDirectory;
    private Consumer<File> textureApplyHandler;

    private static final Color PANEL =
            new Color(30, 32, 37);
    private static final Color HEADER =
            new Color(35, 37, 43);
    private static final Color FIELD =
            new Color(25, 27, 32);
    private static final Color BORDER =
            new Color(53, 56, 64);
    private static final Color TEXT =
            new Color(224, 227, 235);
    private static final Color MUTED =
            new Color(145, 151, 164);
    private static final Color ACCENT =
            new Color(60, 105, 175);

    public FilePanel() {
        setLayout(new BorderLayout(0, 0));
        setBackground(PANEL);
        setBorder(BorderFactory.createMatteBorder(
                1, 0, 0, 0, BORDER
        ));

        setPreferredSize(new Dimension(800, 205));
        setMinimumSize(new Dimension(300, 145));

        // ========================================
        // HEADER
        // ========================================

        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(HEADER);
        header.setBorder(new EmptyBorder(9, 12, 9, 12));

        JLabel title = new JLabel("PROJECT FILES");
        title.setForeground(TEXT);
        title.setFont(new Font("SansSerif", Font.BOLD, 12));

        JLabel subtitle = new JLabel("  Assets and resources");
        subtitle.setForeground(MUTED);
        subtitle.setFont(new Font("SansSerif", Font.PLAIN, 11));

        JPanel titleGroup = new JPanel(new FlowLayout(
                FlowLayout.LEFT, 0, 0
        ));
        titleGroup.setOpaque(false);
        titleGroup.add(title);
        titleGroup.add(subtitle);

        header.add(titleGroup, BorderLayout.WEST);
        add(header, BorderLayout.NORTH);

        // ========================================
        // TOOLBAR
        // ========================================

        JPanel toolbar = new JPanel(new FlowLayout(
                FlowLayout.LEFT, 5, 6
        ));
        toolbar.setBackground(PANEL);
        toolbar.setBorder(new EmptyBorder(2, 7, 2, 7));

        JButton backButton = button("←", "Go to parent folder");
        JButton folderButton = button("+ Folder", "Create a folder");
        JButton fileButton = button("+ File", "Create a text file");
        JButton importButton = button("Import Image", "Import an image into the project");
        JButton textureButton = button("Use as Texture", "Apply the selected image to the selected entity");
        JButton refreshButton = button("↻", "Refresh file list");

        toolbar.add(backButton);
        toolbar.add(folderButton);
        toolbar.add(fileButton);
        toolbar.add(importButton);
        toolbar.add(textureButton);
        toolbar.add(refreshButton);

        // ========================================
        // FILE LIST
        // ========================================

        list.setBackground(PANEL);
        list.setForeground(TEXT);
        list.setSelectionBackground(new Color(45, 77, 125));
        list.setSelectionForeground(Color.WHITE);
        list.setFont(new Font("SansSerif", Font.PLAIN, 12));
        list.setFixedCellHeight(27);
        list.setVisibleRowCount(4);
        list.setBorder(new EmptyBorder(4, 6, 4, 6));
        list.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        list.setCellRenderer(new DefaultListCellRenderer() {
            @Override
            public java.awt.Component getListCellRendererComponent(
                    JList<?> source,
                    Object value,
                    int index,
                    boolean selected,
                    boolean focused) {

                JLabel label = (JLabel) super.getListCellRendererComponent(
                        source, value, index, selected, focused
                );

                label.setOpaque(true);
                label.setBorder(new EmptyBorder(4, 8, 4, 8));
                label.setFont(new Font("SansSerif", Font.PLAIN, 12));

                if (value instanceof File) {
                    File file = (File) value;

                    String icon = file.isDirectory()
                            ? "▰"
                            : isImage(file) ? "▧" : "▤";

                    label.setText("  " + icon + "   " + file.getName());
                    label.setToolTipText(file.getAbsolutePath());

                    if (!selected) {
                        label.setForeground(
                                file.isDirectory()
                                        ? new Color(140, 185, 245)
                                        : TEXT
                        );
                    }
                }

                if (selected) {
                    label.setBackground(new Color(45, 77, 125));
                    label.setForeground(Color.WHITE);
                } else {
                    label.setBackground(PANEL);
                }

                return label;
            }
        });

        list.setDropMode(DropMode.ON);
        list.setDragEnabled(true);
        list.setTransferHandler(new FileTransferHandler());

        JScrollPane scrollPane = new JScrollPane(list);
        scrollPane.setBorder(BorderFactory.createMatteBorder(
                1, 0, 1, 0, BORDER
        ));
        scrollPane.setBackground(PANEL);
        scrollPane.getViewport().setBackground(PANEL);
        scrollPane.getVerticalScrollBar().setUnitIncrement(14);

        // ========================================
        // PATH BAR
        // ========================================

        pathField.setEditable(false);
        pathField.setFocusable(false);
        pathField.setFont(new Font("Monospaced", Font.PLAIN, 11));
        pathField.setForeground(MUTED);
        pathField.setBackground(FIELD);
        pathField.setBorder(new EmptyBorder(8, 11, 8, 11));

        JPanel bottom = new JPanel(new BorderLayout());
        bottom.setBackground(FIELD);
        bottom.add(pathField, BorderLayout.CENTER);

        // ========================================
        // LAYOUT
        // ========================================

        JPanel content = new JPanel(new BorderLayout());
        content.setBackground(PANEL);
        content.add(toolbar, BorderLayout.NORTH);
        content.add(scrollPane, BorderLayout.CENTER);

        add(content, BorderLayout.CENTER);
        add(bottom, BorderLayout.SOUTH);

        // ========================================
        // ACTIONS
        // ========================================

        backButton.addActionListener(e -> goBack());
        folderButton.addActionListener(e -> createFolder());
        fileButton.addActionListener(e -> createTextFile());
        importButton.addActionListener(e -> importImage());
        textureButton.addActionListener(e -> applySelectedTexture());
        refreshButton.addActionListener(e -> refresh());

        list.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent e) {
                int index = list.locationToIndex(e.getPoint());

                if (index >= 0) {
                    Rectangle bounds = list.getCellBounds(index, index);

                    if (bounds != null && bounds.contains(e.getPoint())) {
                        list.setSelectedIndex(index);
                        File selected = list.getSelectedValue();

                        if (e.getClickCount() == 2 && selected != null) {
                            if (selected.isDirectory()) {
                                navigateTo(selected);
                            } else if (isImage(selected)) {
                                applyTexture(selected);
                            }
                        }
                    }
                }

                if (SwingUtilities.isRightMouseButton(e)) {
                    showContextMenu(e.getX(), e.getY());
                }
            }
        });
    }

    private JButton button(String text, String tooltip) {
        JButton button = new JButton(text);

        button.setToolTipText(tooltip);
        button.setFocusable(false);
        button.setFont(new Font("SansSerif", Font.PLAIN, 11));
        button.setForeground(TEXT);
        button.setBackground(new Color(43, 46, 53));
        button.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BORDER),
                new EmptyBorder(5, 8, 5, 8)
        ));
        button.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));

        return button;
    }

    public void setProjectDirectory(File directory) {
        if (directory == null
                || !directory.exists()
                || !directory.isDirectory()) {
            return;
        }

        projectDirectory = directory.getAbsoluteFile();
        currentDirectory = projectDirectory;
        refresh();
    }

    public void setTextureApplyHandler(Consumer<File> handler) {
        textureApplyHandler = handler;
    }

    public void refresh() {
        model.clear();

        if (currentDirectory == null
                || !currentDirectory.isDirectory()) {
            pathField.setText("No project folder selected");
            return;
        }

        pathField.setText("  " + currentDirectory.getAbsolutePath());

        File[] files = currentDirectory.listFiles();

        if (files == null) {
            return;
        }

        Arrays.sort(files, (a, b) -> {
            if (a.isDirectory() != b.isDirectory()) {
                return a.isDirectory() ? -1 : 1;
            }

            return a.getName().compareToIgnoreCase(b.getName());
        });

        for (File file : files) {
            model.addElement(file);
        }
    }

    public File getSelectedFile() {
        return list.getSelectedValue();
    }

    public JList<File> getList() {
        return list;
    }

    public File getProjectDirectory() {
        return projectDirectory;
    }

    public File getCurrentDirectory() {
        return currentDirectory;
    }

    private void navigateTo(File directory) {
        if (directory != null
                && directory.isDirectory()
                && isInsideProject(directory)) {
            currentDirectory = directory;
            refresh();
        }
    }

    private void goBack() {
        if (currentDirectory == null || projectDirectory == null) {
            return;
        }

        File parent = currentDirectory.getParentFile();

        if (parent != null && isInsideProject(parent)) {
            currentDirectory = parent;
            refresh();
        }
    }

    private void createFolder() {
        if (currentDirectory == null) {
            return;
        }

        String name = JOptionPane.showInputDialog(
                this,
                "Folder name:",
                "Create Folder",
                JOptionPane.PLAIN_MESSAGE
        );

        if (name == null || name.trim().isEmpty()) {
            return;
        }

        File folder = new File(currentDirectory, name.trim());

        if (folder.mkdir()) {
            refresh();
        } else {
            showError("Could not create folder. Check the name and permissions.");
        }
    }

    private void createTextFile() {
        if (currentDirectory == null) {
            return;
        }

        String name = JOptionPane.showInputDialog(
                this,
                "File name (for example, notes.txt):",
                "Create Text File",
                JOptionPane.PLAIN_MESSAGE
        );

        if (name == null || name.trim().isEmpty()) {
            return;
        }

        String safeName = name.trim();

        if (safeName.contains("/") || safeName.contains("\\")
                || safeName.equals(".") || safeName.equals("..")) {
            showError("Enter a file name, not a path.");
            return;
        }

        if (!safeName.contains(".")) {
            safeName += ".txt";
        }

        try {
            if (new File(currentDirectory, safeName).createNewFile()) {
                refresh();
            } else {
                showError("A file with that name already exists.");
            }
        } catch (IOException ex) {
            showError("Could not create file: " + ex.getMessage());
        }
    }

    private void importImage() {
        if (currentDirectory == null) {
            return;
        }

        JFileChooser chooser = new JFileChooser();
        chooser.setDialogTitle("Import Image into CodeEngine");
        chooser.setFileSelectionMode(JFileChooser.FILES_ONLY);
        chooser.setAcceptAllFileFilterUsed(false);

        chooser.addChoosableFileFilter(
                new FileNameExtensionFilter(
                        "Images (PNG, JPG, GIF, BMP)",
                        "png", "jpg", "jpeg", "gif", "bmp"
                )
        );

        if (chooser.showOpenDialog(this) == JFileChooser.APPROVE_OPTION) {
            copyExternalImage(
                    chooser.getSelectedFile(),
                    currentDirectory
            );
        }
    }

    private void applySelectedTexture() {
        File selected = getSelectedFile();

        if (selected == null
                || selected.isDirectory()
                || !isImage(selected)) {
            showError("Select an image file first.");
            return;
        }

        applyTexture(selected);
    }

    private void applyTexture(File image) {
        if (textureApplyHandler == null) {
            showError("Select an Entity in Hierarchy first.");
            return;
        }

        textureApplyHandler.accept(image);
    }

    private void showContextMenu(int x, int y) {
        int index = list.locationToIndex(new Point(x, y));

        if (index >= 0) {
            Rectangle bounds = list.getCellBounds(index, index);

            if (bounds != null && bounds.contains(x, y)) {
                list.setSelectedIndex(index);
            } else {
                list.clearSelection();
            }
        } else {
            list.clearSelection();
        }

        File selected = list.getSelectedValue();

        JPopupMenu menu = new JPopupMenu();

        JMenuItem open = new JMenuItem("Open");
        JMenuItem useTexture = new JMenuItem("Use as Texture");
        JMenuItem rename = new JMenuItem("Rename");
        JMenuItem delete = new JMenuItem("Delete");

        open.addActionListener(e -> {
            File file = getSelectedFile();

            if (file != null && file.isDirectory()) {
                navigateTo(file);
            } else if (file != null && isImage(file)) {
                applyTexture(file);
            }
        });

        useTexture.addActionListener(e -> applySelectedTexture());
        rename.addActionListener(e -> renameSelected());
        delete.addActionListener(e -> deleteSelected());

        boolean hasSelection = selected != null;

        open.setEnabled(hasSelection);
        rename.setEnabled(hasSelection);
        delete.setEnabled(hasSelection);
        useTexture.setEnabled(
                hasSelection && selected.isFile() && isImage(selected)
        );

        menu.add(open);
        menu.addSeparator();
        menu.add(useTexture);
        menu.addSeparator();
        menu.add(rename);
        menu.add(delete);

        menu.show(list, x, y);
    }

    private void renameSelected() {
        File selected = getSelectedFile();

        if (selected == null) {
            return;
        }

        String name = JOptionPane.showInputDialog(
                this,
                "New name:",
                selected.getName()
        );

        if (name == null || name.trim().isEmpty()) {
            return;
        }

        String safeName = name.trim();

        if (safeName.contains("/") || safeName.contains("\\")
                || safeName.equals(".") || safeName.equals("..")) {
            showError("Enter a name, not a path.");
            return;
        }

        File destination = new File(
                selected.getParentFile(),
                safeName
        );

        if (destination.exists()) {
            showError("That name already exists.");
            return;
        }

        if (selected.renameTo(destination)) {
            refresh();
        } else {
            showError("Could not rename item.");
        }
    }

    private void deleteSelected() {
        File selected = getSelectedFile();

        if (selected == null) {
            return;
        }

        if (selected.isDirectory()) {
            File[] children = selected.listFiles();

            if (children != null && children.length > 0) {
                showError(
                        "Folder is not empty. Move or delete its contents first."
                );
                return;
            }
        }

        int answer = JOptionPane.showConfirmDialog(
                this,
                "Delete '" + selected.getName() + "'?",
                "Confirm Delete",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.WARNING_MESSAGE
        );

        if (answer == JOptionPane.YES_OPTION) {
            if (selected.delete()) {
                refresh();
            } else {
                showError("Could not delete item.");
            }
        }
    }

    private void copyExternalImage(
            File source,
            File destinationDirectory) {

        if (!isImage(source)) {
            showError("Only image files can be imported.");
            return;
        }

        File destination = uniqueDestination(
                destinationDirectory,
                source.getName()
        );

        try {
            Files.copy(
                    source.toPath(),
                    destination.toPath(),
                    StandardCopyOption.COPY_ATTRIBUTES
            );

            refresh();
        } catch (IOException ex) {
            showError("Could not import image: " + ex.getMessage());
        }
    }

    private File dropTarget(TransferHandler.TransferSupport support) {
        File target = currentDirectory;

        if (support.isDrop()
                && support.getDropLocation() instanceof JList.DropLocation) {

            JList.DropLocation location =
                    (JList.DropLocation) support.getDropLocation();

            int index = location.getIndex();

            if (index >= 0 && index < model.size()) {
                File hovered = model.get(index);

                if (hovered.isDirectory()) {
                    target = hovered;
                }
            }
        }

        return target;
    }

    private boolean isInsideProject(File file) {
        if (projectDirectory == null || file == null) {
            return false;
        }

        try {
            String root = projectDirectory.getCanonicalPath();
            String candidate = file.getCanonicalPath();

            return candidate.equals(root)
                    || candidate.startsWith(root + File.separator);
        } catch (IOException ex) {
            return false;
        }
    }

    private static boolean isImage(File file) {
        String name = file.getName().toLowerCase(Locale.ROOT);

        return name.endsWith(".png")
                || name.endsWith(".jpg")
                || name.endsWith(".jpeg")
                || name.endsWith(".gif")
                || name.endsWith(".bmp");
    }

    private static File uniqueDestination(File directory, String name) {
        File destination = new File(directory, name);

        if (!destination.exists()) {
            return destination;
        }

        String base = name;
        String extension = "";

        int dot = name.lastIndexOf('.');

        if (dot > 0) {
            base = name.substring(0, dot);
            extension = name.substring(dot);
        }

        int index = 1;

        do {
            destination = new File(
                    directory,
                    base + "_" + index++ + extension
            );
        } while (destination.exists());

        return destination;
    }

    private void showError(String message) {
        JOptionPane.showMessageDialog(
                this,
                message,
                "CodeEngine Studio",
                JOptionPane.INFORMATION_MESSAGE
        );
    }

    private final class FileTransferHandler extends TransferHandler {

        @Override
        public boolean canImport(TransferSupport support) {
            return support.isDataFlavorSupported(
                    DataFlavor.javaFileListFlavor
            );
        }

        @Override
        public int getSourceActions(JComponent component) {
            return COPY_OR_MOVE;
        }

        @Override
        protected Transferable createTransferable(JComponent component) {
            File selected = list.getSelectedValue();

            if (selected == null || selected.equals(projectDirectory)) {
                return null;
            }

            return new Transferable() {
                private final List<File> files =
                        Collections.singletonList(selected);

                @Override
                public DataFlavor[] getTransferDataFlavors() {
                    return new DataFlavor[]{
                            DataFlavor.javaFileListFlavor
                    };
                }

                @Override
                public boolean isDataFlavorSupported(DataFlavor flavor) {
                    return DataFlavor.javaFileListFlavor.equals(flavor);
                }

                @Override
                public Object getTransferData(DataFlavor flavor)
                        throws java.awt.datatransfer.UnsupportedFlavorException {

                    if (!isDataFlavorSupported(flavor)) {
                        throw new java.awt.datatransfer.UnsupportedFlavorException(
                                flavor
                        );
                    }

                    return files;
                }
            };
        }

        @Override
        protected void exportDone(
                JComponent source,
                Transferable data,
                int action) {
            // Перетаскивание в Inspector не удаляет исходный ресурс.
        }

        @Override
        public boolean importData(TransferSupport support) {
            if (!canImport(support) || currentDirectory == null) {
                return false;
            }

            try {
                @SuppressWarnings("unchecked")
                List<File> incoming = (List<File>)
                        support.getTransferable().getTransferData(
                                DataFlavor.javaFileListFlavor
                        );

                File targetDirectory = dropTarget(support);

                if (targetDirectory == null
                        || !targetDirectory.isDirectory()) {
                    targetDirectory = currentDirectory;
                }

                boolean changed = false;

                for (File source : incoming) {
                    if (source == null
                            || !source.exists()
                            || source.equals(targetDirectory)) {
                        continue;
                    }

                    if (isInsideProject(source)) {
                        if (source.isDirectory()
                                && targetDirectory.toPath().startsWith(
                                        source.toPath())) {
                            continue;
                        }

                        File destination = uniqueDestination(
                                targetDirectory,
                                source.getName()
                        );

                        try {
                            Files.move(
                                    source.toPath(),
                                    destination.toPath()
                            );
                            changed = true;
                        } catch (IOException ex) {
                            showError(
                                    "Could not move '"
                                            + source.getName()
                                            + "': "
                                            + ex.getMessage()
                            );
                        }
                    } else if (isImage(source)) {
                        copyExternalImage(source, targetDirectory);
                        changed = true;
                    }
                }

                refresh();
                return changed;

            } catch (Exception ex) {
                showError("Drop failed: " + ex.getMessage());
                return false;
            }
        }
    }
}
