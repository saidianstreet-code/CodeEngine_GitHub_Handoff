package codeengine;

import javax.swing.JPanel;
import javax.swing.SwingUtilities;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;
import java.awt.event.MouseWheelEvent;

public class GameViewPanel extends JPanel {

    private Scene scene;

    private final Camera2D camera;

    private HierarchyPanel hierarchyPanel;

    private Entity selectedEntity;

    // ========================================
    // MOUSE
    // ========================================

    private int lastMouseX;
    private int lastMouseY;

    private boolean panning = false;
    private boolean draggingEntity = false;
    private boolean resizingEntity = false;

    private ResizeHandle resizeHandle =
            ResizeHandle.NONE;

    // ========================================
    // ENUM
    // ========================================

    private enum ResizeHandle {

        NONE,

        TOP_LEFT,
        TOP,
        TOP_RIGHT,

        LEFT,
        RIGHT,

        BOTTOM_LEFT,
        BOTTOM,
        BOTTOM_RIGHT
    }

    // ========================================
    // CONSTRUCTOR
    // ========================================

    public GameViewPanel() {

        setBackground(
                new Color(
                        25,
                        25,
                        28
                )
        );

        setFocusable(true);

        // Принимаем клавиатурный ввод для управления объектами в Play Mode.
        addKeyListener(Input.getInstance());

        // WASD и стрелки не должны перехватываться Swing как клавиши
        // переключения фокуса между элементами интерфейса.
        setFocusTraversalKeysEnabled(false);

        setDoubleBuffered(true);

        camera =
                new Camera2D();

        camera.setPosition(
                640,
                360
        );

        setupMouseControls();
    }

    // ========================================
    // SCENE
    // ========================================

    public void setScene(
            Scene scene
    ) {

        this.scene =
                scene;

        selectedEntity = null;

        draggingEntity = false;
        resizingEntity = false;

        resizeHandle =
                ResizeHandle.NONE;

        centerCameraOnScene();

        repaint();
    }

    public Scene getScene() {

        return scene;
    }

    // ========================================
    // CAMERA
    // ========================================

    public Camera2D getCamera() {

        return camera;
    }

    // ========================================
    // HIERARCHY
    // ========================================

    public void setHierarchyPanel(
            HierarchyPanel hierarchyPanel
    ) {

        this.hierarchyPanel =
                hierarchyPanel;
    }

    // ========================================
    // SELECTED ENTITY
    // ========================================

    public Entity getSelectedEntity() {

        return selectedEntity;
    }

    public void setSelectedEntity(
            Entity entity
    ) {

        selectedEntity =
                entity;

        repaint();
    }

    // ========================================
    // CENTER CAMERA
    // ========================================

    public void centerCameraOnScene() {

        if (scene == null) {
            return;
        }

        if (scene.getEntities().isEmpty()) {
            return;
        }

        double minX =
                Double.MAX_VALUE;

        double minY =
                Double.MAX_VALUE;

        double maxX =
                -Double.MAX_VALUE;

        double maxY =
                -Double.MAX_VALUE;

        for (
                Entity entity :
                scene.getEntities()
        ) {

            double x =
                    entity.getX();

            double y =
                    entity.getY();

            double right =
                    x + entity.getWidth();

            double bottom =
                    y + entity.getHeight();

            minX =
                    Math.min(
                            minX,
                            x
                    );

            minY =
                    Math.min(
                            minY,
                            y
                    );

            maxX =
                    Math.max(
                            maxX,
                            right
                    );

            maxY =
                    Math.max(
                            maxY,
                            bottom
                    );
        }

        camera.setPosition(
                (minX + maxX) / 2.0,
                (minY + maxY) / 2.0
        );
    }

    // ========================================
    // MOUSE CONTROLS
    // ========================================

    private void setupMouseControls() {

        addMouseListener(
                new MouseAdapter() {

                    @Override
                    public void mousePressed(
                            MouseEvent e
                    ) {

                        requestFocusInWindow();

                        lastMouseX =
                                e.getX();

                        lastMouseY =
                                e.getY();

                        // --------------------
                        // MIDDLE MOUSE
                        // --------------------

                        if (
                                SwingUtilities
                                        .isMiddleMouseButton(e)
                        ) {

                            panning = true;

                            return;
                        }

                        // --------------------
                        // LEFT MOUSE
                        // --------------------

                        if (
                                SwingUtilities
                                        .isLeftMouseButton(e)
                        ) {

                            handleLeftMousePressed(
                                    e.getX(),
                                    e.getY()
                            );
                        }
                    }

                    @Override
                    public void mouseReleased(
                            MouseEvent e
                    ) {

                        if (
                                SwingUtilities
                                        .isMiddleMouseButton(e)
                        ) {

                            panning = false;
                        }

                        if (
                                SwingUtilities
                                        .isLeftMouseButton(e)
                        ) {

                            draggingEntity = false;

                            resizingEntity = false;

                            resizeHandle =
                                    ResizeHandle.NONE;
                        }
                    }
                }
        );

        // ====================================
        // MOUSE DRAG
        // ====================================

        addMouseMotionListener(
                new MouseMotionAdapter() {

                    @Override
                    public void mouseDragged(
                            MouseEvent e
                    ) {

                        int mouseX =
                                e.getX();

                        int mouseY =
                                e.getY();

                        int dx =
                                mouseX
                                        - lastMouseX;

                        int dy =
                                mouseY
                                        - lastMouseY;

                        // --------------------
                        // CAMERA PAN
                        // --------------------

                        if (
                                panning
                                        ||
                                isSpacePressed()
                        ) {

                            double zoom =
                                    camera.getZoom();

                            if (zoom <= 0) {
                                zoom = 1;
                            }

                            camera.move(
                                    -dx / zoom,
                                    -dy / zoom
                            );

                            lastMouseX =
                                    mouseX;

                            lastMouseY =
                                    mouseY;

                            repaint();

                            return;
                        }

                        // --------------------
                        // ENTITY MOVE
                        // --------------------

                        if (
                                draggingEntity
                                        &&
                                selectedEntity != null
                        ) {

                            double zoom =
                                    camera.getZoom();

                            selectedEntity.move(
                                    dx / zoom,
                                    dy / zoom
                            );

                            lastMouseX =
                                    mouseX;

                            lastMouseY =
                                    mouseY;

                            repaint();

                            return;
                        }

                        // --------------------
                        // ENTITY RESIZE
                        // --------------------

                        if (
                                resizingEntity
                                        &&
                                selectedEntity != null
                        ) {

                            resizeSelectedEntity(
                                    dx,
                                    dy
                            );

                            lastMouseX =
                                    mouseX;

                            lastMouseY =
                                    mouseY;

                            repaint();
                        }
                    }
                }
        );

        // ====================================
        // MOUSE WHEEL
        // ====================================

        addMouseWheelListener(
                this::handleMouseWheel
        );
    }

    // ========================================
    // LEFT MOUSE PRESSED
    // ========================================

    private void handleLeftMousePressed(
            int screenX,
            int screenY
    ) {

        // ------------------------------------
        // RESIZE HANDLE
        // ------------------------------------

        if (selectedEntity != null) {

            ResizeHandle handle =
                    getResizeHandle(
                            screenX,
                            screenY
                    );

            if (
                    handle
                            != ResizeHandle.NONE
            ) {

                resizingEntity = true;

                resizeHandle =
                        handle;

                return;
            }
        }

        // ------------------------------------
        // FIND ENTITY
        // ------------------------------------

        Entity entity =
                findEntityAt(
                        screenX,
                        screenY
                );

        if (entity != null) {

            selectEntity(
                    entity
            );

            draggingEntity = true;

            return;
        }

        // ------------------------------------
        // EMPTY SPACE
        // ------------------------------------

        selectedEntity = null;

        if (hierarchyPanel != null) {

            hierarchyPanel
                    .clearSelection();
        }

        repaint();
    }

    // ========================================
    // FIND ENTITY
    // ========================================

    private Entity findEntityAt(
            int screenX,
            int screenY
    ) {

        if (scene == null) {
            return null;
        }

        double worldX =
                camera.screenToWorldX(
                        screenX,
                        getWidth()
                );

        double worldY =
                camera.screenToWorldY(
                        screenY,
                        getHeight()
                );

        for (
                int i =
                        scene.getEntities().size() - 1;
                i >= 0;
                i--
        ) {

            Entity entity =
                    scene.getEntities()
                            .get(i);

            if (!entity.isVisible()) {
                continue;
            }

            if (
                    entity.contains(
                            worldX,
                            worldY
                    )
            ) {

                return entity;
            }
        }

        return null;
    }

    // ========================================
    // SELECT
    // ========================================

    private void selectEntity(
            Entity entity
    ) {

        selectedEntity =
                entity;

        if (hierarchyPanel != null) {

            hierarchyPanel
                    .selectEntity(
                            entity
                    );
        }

        repaint();
    }

    // ========================================
    // RESIZE HANDLE
    // ========================================

    private ResizeHandle getResizeHandle(
            int screenX,
            int screenY
    ) {

        if (selectedEntity == null) {
            return ResizeHandle.NONE;
        }

        double x =
                camera.worldToScreenX(
                        selectedEntity.getX(),
                        getWidth()
                );

        double y =
                camera.worldToScreenY(
                        selectedEntity.getY(),
                        getHeight()
                );

        double right =
                camera.worldToScreenX(
                        selectedEntity.getX()
                                + selectedEntity.getWidth(),
                        getWidth()
                );

        double bottom =
                camera.worldToScreenY(
                        selectedEntity.getY()
                                + selectedEntity.getHeight(),
                        getHeight()
                );

        int size = 8;

        int centerX =
                (int) ((x + right) / 2);

        int centerY =
                (int) ((y + bottom) / 2);

        if (isNear(
                screenX,
                screenY,
                x,
                y,
                size
        )) {
            return ResizeHandle.TOP_LEFT;
        }

        if (isNear(
                screenX,
                screenY,
                centerX,
                y,
                size
        )) {
            return ResizeHandle.TOP;
        }

        if (isNear(
                screenX,
                screenY,
                right,
                y,
                size
        )) {
            return ResizeHandle.TOP_RIGHT;
        }

        if (isNear(
                screenX,
                screenY,
                x,
                centerY,
                size
        )) {
            return ResizeHandle.LEFT;
        }

        if (isNear(
                screenX,
                screenY,
                right,
                centerY,
                size
        )) {
            return ResizeHandle.RIGHT;
        }

        if (isNear(
                screenX,
                screenY,
                x,
                bottom,
                size
        )) {
            return ResizeHandle.BOTTOM_LEFT;
        }

        if (isNear(
                screenX,
                screenY,
                centerX,
                bottom,
                size
        )) {
            return ResizeHandle.BOTTOM;
        }

        if (isNear(
                screenX,
                screenY,
                right,
                bottom,
                size
        )) {
            return ResizeHandle.BOTTOM_RIGHT;
        }

        return ResizeHandle.NONE;
    }

    // ========================================
    // HANDLE TEST
    // ========================================

    private boolean isNear(
            int mouseX,
            int mouseY,
            double x,
            double y,
            int size
    ) {

        return Math.abs(
                mouseX - x
        ) <= size
                &&
                Math.abs(
                        mouseY - y
                ) <= size;
    }

    // ========================================
    // RESIZE ENTITY
    // ========================================

    private void resizeSelectedEntity(
            int screenDX,
            int screenDY
    ) {

        Entity entity =
                selectedEntity;

        if (entity == null) {
            return;
        }

        double zoom =
                camera.getZoom();

        if (zoom <= 0) {
            zoom = 1;
        }

        double dx =
                screenDX / zoom;

        double dy =
                screenDY / zoom;

        double x =
                entity.getX();

        double y =
                entity.getY();

        double width =
                entity.getWidth();

        double height =
                entity.getHeight();

        double minSize = 5;

        switch (resizeHandle) {

            case TOP_LEFT:

                x += dx;
                y += dy;

                width -= dx;
                height -= dy;

                break;

            case TOP:

                y += dy;
                height -= dy;

                break;

            case TOP_RIGHT:

                y += dy;

                width += dx;
                height -= dy;

                break;

            case LEFT:

                x += dx;
                width -= dx;

                break;

            case RIGHT:

                width += dx;

                break;

            case BOTTOM_LEFT:

                x += dx;

                width -= dx;
                height += dy;

                break;

            case BOTTOM:

                height += dy;

                break;

            case BOTTOM_RIGHT:

                width += dx;
                height += dy;

                break;

            default:
                return;
        }

        // ------------------------------------
        // MIN SIZE
        // ------------------------------------

        if (width < minSize) {

            if (
                    resizeHandle
                            == ResizeHandle.TOP_LEFT
                            ||
                    resizeHandle
                            == ResizeHandle.LEFT
                            ||
                    resizeHandle
                            == ResizeHandle.BOTTOM_LEFT
            ) {

                x =
                        entity.getX()
                                + entity.getWidth()
                                - minSize;
            }

            width =
                    minSize;
        }

        if (height < minSize) {

            if (
                    resizeHandle
                            == ResizeHandle.TOP_LEFT
                            ||
                    resizeHandle
                            == ResizeHandle.TOP
                            ||
                    resizeHandle
                            == ResizeHandle.TOP_RIGHT
            ) {

                y =
                        entity.getY()
                                + entity.getHeight()
                                - minSize;
            }

            height =
                    minSize;
        }

        entity.setPosition(
                x,
                y
        );

        entity.setSize(
                width,
                height
        );
    }

    // ========================================
    // ZOOM
    // ========================================

    private void handleMouseWheel(
            MouseWheelEvent e
    ) {

        if (scene == null) {
            return;
        }

        double oldZoom =
                camera.getZoom();

        double factor =
                Math.pow(
                        1.1,
                        -e.getWheelRotation()
                );

        double newZoom =
                oldZoom * factor;

        newZoom =
                Math.max(
                        0.1,
                        Math.min(
                                5.0,
                                newZoom
                        )
                );

        double mouseWorldX =
                camera.screenToWorldX(
                        e.getX(),
                        getWidth()
                );

        double mouseWorldY =
                camera.screenToWorldY(
                        e.getY(),
                        getHeight()
                );

        camera.setZoom(
                newZoom
        );

        double newMouseWorldX =
                camera.screenToWorldX(
                        e.getX(),
                        getWidth()
                );

        double newMouseWorldY =
                camera.screenToWorldY(
                        e.getY(),
                        getHeight()
                );

        camera.move(
                mouseWorldX
                        - newMouseWorldX,

                mouseWorldY
                        - newMouseWorldY
        );

        repaint();
    }

    // ========================================
    // SPACE
    // ========================================

    private boolean isSpacePressed() {

        return Input.isKeyDown(
                Key.SPACE
        );
    }

    // ========================================
    // RENDER
    // ========================================

    @Override
    protected void paintComponent(
            Graphics graphics
    ) {

        super.paintComponent(
                graphics
        );

        Graphics2D g2 =
                (Graphics2D) graphics;

        g2.setRenderingHint(
                RenderingHints.KEY_ANTIALIASING,
                RenderingHints.VALUE_ANTIALIAS_ON
        );

        if (scene == null) {

            drawEmptyView(g2);

            return;
        }

        drawGrid(g2);

        for (
                Entity entity :
                scene.getEntities()
        ) {

            if (!entity.isVisible()) {
                continue;
            }

            int x =
                    (int)
                            camera.worldToScreenX(
                                    entity.getX(),
                                    getWidth()
                            );

            int y =
                    (int)
                            camera.worldToScreenY(
                                    entity.getY(),
                                    getHeight()
                            );

            int width =
                    (int)
                            (
                                    entity.getWidth()
                                            * camera.getZoom()
                            );

            int height =
                    (int)
                            (
                                    entity.getHeight()
                                            * camera.getZoom()
                            );

            // --------------------------------
            // ENTITY / SPRITE
            // --------------------------------

            ColorRenderer colorRenderer =
                    entity.getComponent(ColorRenderer.class);
            SpriteRenderer spriteRenderer =
                    entity.getComponent(SpriteRenderer.class);

            boolean drewColor = false;
            if (colorRenderer != null && colorRenderer.isEnabled()
                    && colorRenderer.isVisible()) {
                g2.setColor(colorRenderer.getColor());
                g2.fillRect(x, y, width, height);
                drewColor = true;
            }

            if (spriteRenderer != null && spriteRenderer.isEnabled()
                    && spriteRenderer.isVisible()
                    && spriteRenderer.getTexture() != null) {
                g2.drawImage(spriteRenderer.getTexture(), x, y, width, height, null);
            } else if (colorRenderer == null
                    && (spriteRenderer == null || spriteRenderer.getTexture() == null)) {
                // Backward-compatible default when no color component/texture is available.
                g2.setColor(entity.getColor());
                g2.fillRect(x, y, width, height);
            }

            // --------------------------------
            // OUTLINE
            // --------------------------------

            g2.setColor(
                    new Color(
                            20,
                            20,
                            20
                    )
            );

            g2.drawRect(
                    x,
                    y,
                    width,
                    height
            );

            // --------------------------------
            // SELECTED
            // --------------------------------

            if (
                    entity
                            == selectedEntity
            ) {

                drawSelectionBox(
                        g2,
                        x,
                        y,
                        width,
                        height
                );
            }

            // --------------------------------
            // NAME
            // --------------------------------

            g2.setColor(
                    Color.WHITE
            );

            g2.drawString(
                    entity.getName(),
                    x,
                    y - 7
            );
        }

        drawCrosshair(g2);
    }

    // ========================================
    // SELECTION BOX
    // ========================================

    private void drawSelectionBox(
            Graphics2D g2,
            int x,
            int y,
            int width,
            int height
    ) {

        g2.setColor(
                new Color(
                        0,
                        180,
                        255
                )
        );

        g2.drawRect(
                x - 2,
                y - 2,
                width + 4,
                height + 4
        );

        // Handles

        drawHandle(
                g2,
                x,
                y
        );

        drawHandle(
                g2,
                x + width / 2,
                y
        );

        drawHandle(
                g2,
                x + width,
                y
        );

        drawHandle(
                g2,
                x,
                y + height / 2
        );

        drawHandle(
                g2,
                x + width,
                y + height / 2
        );

        drawHandle(
                g2,
                x,
                y + height
        );

        drawHandle(
                g2,
                x + width / 2,
                y + height
        );

        drawHandle(
                g2,
                x + width,
                y + height
        );
    }

    // ========================================
    // HANDLE DRAW
    // ========================================

    private void drawHandle(
            Graphics2D g2,
            int x,
            int y
    ) {

        int size = 8;

        g2.setColor(
                Color.WHITE
        );

        g2.fillRect(
                x - size / 2,
                y - size / 2,
                size,
                size
        );

        g2.setColor(
                new Color(
                        0,
                        140,
                        220
                )
        );

        g2.drawRect(
                x - size / 2,
                y - size / 2,
                size,
                size
        );
    }

    // ========================================
    // GRID
    // ========================================

    private void drawGrid(
            Graphics2D g2
    ) {

        int gridSize =
                (int)
                        (
                                50
                                        * camera.getZoom()
                        );

        if (gridSize < 10) {
            gridSize = 10;
        }

        g2.setColor(
                new Color(
                        45,
                        45,
                        48
                )
        );

        int offsetX =
                (int)
                        (
                                camera.worldToScreenX(
                                        0,
                                        getWidth()
                                )
                                        % gridSize
                        );

        int offsetY =
                (int)
                        (
                                camera.worldToScreenY(
                                        0,
                                        getHeight()
                                )
                                        % gridSize
                        );

        if (offsetX < 0) {
            offsetX += gridSize;
        }

        if (offsetY < 0) {
            offsetY += gridSize;
        }

        for (
                int x = offsetX;
                x < getWidth();
                x += gridSize
        ) {

            g2.drawLine(
                    x,
                    0,
                    x,
                    getHeight()
            );
        }

        for (
                int y = offsetY;
                y < getHeight();
                y += gridSize
        ) {

            g2.drawLine(
                    0,
                    y,
                    getWidth(),
                    y
            );
        }
    }

    // ========================================
    // CROSSHAIR
    // ========================================

    private void drawCrosshair(
            Graphics2D g2
    ) {

        int centerX =
                getWidth() / 2;

        int centerY =
                getHeight() / 2;

        g2.setColor(
                new Color(
                        120,
                        120,
                        120
                )
        );

        g2.drawLine(
                centerX - 8,
                centerY,
                centerX + 8,
                centerY
        );

        g2.drawLine(
                centerX,
                centerY - 8,
                centerX,
                centerY + 8
        );
    }

    // ========================================
    // EMPTY VIEW
    // ========================================

    private void drawEmptyView(
            Graphics2D g2
    ) {

        g2.setColor(
                new Color(
                        30,
                        30,
                        32
                )
        );

        g2.fillRect(
                0,
                0,
                getWidth(),
                getHeight()
        );

        g2.setColor(
                new Color(
                        150,
                        150,
                        150
                )
        );

        String text =
                "GAME VIEW";

        int textWidth =
                g2.getFontMetrics()
                        .stringWidth(text);

        int x =
                (
                        getWidth()
                                - textWidth
                ) / 2;

        int y =
                getHeight() / 2;

        g2.drawString(
                text,
                x,
                y
        );
    }
}