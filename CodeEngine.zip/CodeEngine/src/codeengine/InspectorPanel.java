
package codeengine;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.datatransfer.DataFlavor;
import java.io.File;
import java.util.List;

public class InspectorPanel extends JPanel {

    private Entity entity;

    private final JLabel entityNameLabel;

    private final JTextField xField;
    private final JTextField yField;
    private final JTextField widthField;
    private final JTextField heightField;

    private final JLabel statusLabel;
    private final JButton applyButton;
    private final JButton addComponentButton;
    private final JPanel componentContainer;

    private final Color panelColor =
            new Color(35, 35, 38);

    private final Color fieldColor =
            new Color(28, 28, 31);

    public InspectorPanel() {

        setLayout(new BorderLayout());
        setPreferredSize(new Dimension(270, 0));
        setBackground(panelColor);

        // HEADER
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(new Color(45, 45, 48));
        header.setBorder(
                new EmptyBorder(10, 12, 10, 12)
        );

        JLabel title = new JLabel("Inspector");
        title.setForeground(Color.WHITE);
        title.setFont(
                new Font("Arial", Font.BOLD, 15)
        );

        header.add(title, BorderLayout.NORTH);

        entityNameLabel = new JLabel("No object selected");
        entityNameLabel.setForeground(
                new Color(180, 180, 185)
        );
        entityNameLabel.setFont(
                new Font("Arial", Font.PLAIN, 12)
        );

        header.add(entityNameLabel, BorderLayout.SOUTH);
        add(header, BorderLayout.NORTH);

        // CONTENT
        JPanel content = new JPanel();
        content.setLayout(
                new BoxLayout(content, BoxLayout.Y_AXIS)
        );
        content.setBackground(panelColor);
        content.setBorder(
                new EmptyBorder(12, 12, 12, 12)
        );

        // TRANSFORM
        JLabel transformTitle = createSectionTitle("Transform");
        content.add(transformTitle);
        content.add(Box.createVerticalStrut(10));

        xField = createField();
        yField = createField();
        widthField = createField();
        heightField = createField();

        content.add(createRow("X", xField));
        content.add(createRow("Y", yField));
        content.add(Box.createVerticalStrut(6));
        content.add(createRow("Width", widthField));
        content.add(createRow("Height", heightField));
        content.add(Box.createVerticalStrut(12));

        // APPLY
        applyButton = createButton(
                "Apply Changes",
                new Color(65, 100, 145)
        );
        applyButton.addActionListener(
                e -> applyChanges()
        );
        content.add(applyButton);

        statusLabel = new JLabel(" ");
        statusLabel.setForeground(
                new Color(150, 150, 155)
        );
        statusLabel.setFont(
                new Font("Arial", Font.PLAIN, 11)
        );
        statusLabel.setAlignmentX(LEFT_ALIGNMENT);

        content.add(Box.createVerticalStrut(5));
        content.add(statusLabel);
        content.add(Box.createVerticalStrut(12));

        // COMPONENTS SECTION
        content.add(createSectionTitle("Components"));
        content.add(Box.createVerticalStrut(8));

        componentContainer = new JPanel();
        componentContainer.setLayout(
                new BoxLayout(
                        componentContainer,
                        BoxLayout.Y_AXIS
                )
        );
        componentContainer.setBackground(panelColor);
        componentContainer.setAlignmentX(LEFT_ALIGNMENT);

        content.add(componentContainer);
        content.add(Box.createVerticalStrut(10));

        addComponentButton = createButton(
                "+ Add Component",
                new Color(65, 100, 80)
        );
        addComponentButton.addActionListener(
                e -> showAddComponentMenu()
        );

        content.add(addComponentButton);

        // ENTER = APPLY
        xField.addActionListener(e -> applyChanges());
        yField.addActionListener(e -> applyChanges());
        widthField.addActionListener(e -> applyChanges());
        heightField.addActionListener(e -> applyChanges());

        // SCROLL
        JScrollPane scrollPane = new JScrollPane(content);
        scrollPane.setBorder(BorderFactory.createEmptyBorder());
        scrollPane.setBackground(panelColor);
        scrollPane.getViewport().setBackground(panelColor);
        scrollPane.getVerticalScrollBar().setUnitIncrement(12);

        add(scrollPane, BorderLayout.CENTER);

        setFieldsEnabled(false);
        refreshComponents();
    }

    private JLabel createSectionTitle(String text) {

        JLabel label = new JLabel(text);
        label.setForeground(Color.WHITE);
        label.setFont(
                new Font("Arial", Font.BOLD, 14)
        );
        label.setAlignmentX(LEFT_ALIGNMENT);

        return label;
    }

    private JTextField createField() {

        JTextField field = new JTextField();

        field.setMaximumSize(
                new Dimension(Integer.MAX_VALUE, 30)
        );
        field.setPreferredSize(new Dimension(120, 30));
        field.setBackground(fieldColor);
        field.setForeground(Color.WHITE);
        field.setCaretColor(Color.WHITE);

        field.setBorder(
                BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(
                                new Color(70, 70, 75)
                        ),
                        BorderFactory.createEmptyBorder(
                                4, 7, 4, 7
                        )
                )
        );

        return field;
    }

    private JPanel createRow(
            String name,
            java.awt.Component field
    ) {

        JPanel row = new JPanel(
                new BorderLayout(8, 0)
        );

        row.setBackground(panelColor);
        row.setMaximumSize(
                new Dimension(Integer.MAX_VALUE, 35)
        );
        row.setAlignmentX(LEFT_ALIGNMENT);

        JLabel label = new JLabel(name);
        label.setForeground(
                new Color(200, 200, 205)
        );
        label.setPreferredSize(new Dimension(55, 30));

        row.add(label, BorderLayout.WEST);
        row.add(field, BorderLayout.CENTER);

        return row;
    }

    private JButton createButton(
            String text,
            Color background
    ) {

        JButton button = new JButton(text);

        button.setAlignmentX(LEFT_ALIGNMENT);
        button.setMaximumSize(
                new Dimension(Integer.MAX_VALUE, 32)
        );
        button.setPreferredSize(new Dimension(220, 32));
        button.setFocusPainted(false);
        button.setForeground(Color.WHITE);
        button.setBackground(background);
        button.setBorder(
                BorderFactory.createEmptyBorder(5, 8, 5, 8)
        );

        return button;
    }

    // ========================================
    // SELECT ENTITY
    // ========================================

    public void setEntity(Entity entity) {

        this.entity = entity;

        if (entity == null) {

            entityNameLabel.setText("No object selected");

            xField.setText("");
            yField.setText("");
            widthField.setText("");
            heightField.setText("");

            statusLabel.setText(" ");

            setFieldsEnabled(false);
            refreshComponents();

            return;
        }

        entityNameLabel.setText(entity.getName());

        xField.setText(formatNumber(entity.getX()));
        yField.setText(formatNumber(entity.getY()));
        widthField.setText(formatNumber(entity.getWidth()));
        heightField.setText(formatNumber(entity.getHeight()));

        statusLabel.setText(" ");

        setFieldsEnabled(true);
        refreshComponents();
    }

    private void setFieldsEnabled(boolean enabled) {

        xField.setEnabled(enabled);
        yField.setEnabled(enabled);
        widthField.setEnabled(enabled);
        heightField.setEnabled(enabled);
        applyButton.setEnabled(enabled);
        addComponentButton.setEnabled(enabled);
    }

    // ========================================
    // APPLY TRANSFORM
    // ========================================

    private void applyChanges() {

        if (entity == null) {
            return;
        }

        try {

            double x = parseNumber(xField.getText());
            double y = parseNumber(yField.getText());
            double width = parseNumber(widthField.getText());
            double height = parseNumber(heightField.getText());

            if (width <= 0 || height <= 0) {
                throw new NumberFormatException();
            }

            entity.setPosition(x, y);
            entity.setSize(width, height);

            statusLabel.setForeground(
                    new Color(120, 200, 120)
            );
            statusLabel.setText("Changes applied");

            repaintGameView();

        } catch (NumberFormatException exception) {

            statusLabel.setForeground(
                    new Color(230, 100, 100)
            );
            statusLabel.setText("Enter valid numbers");
        }
    }

    private double parseNumber(String text) {

        return Double.parseDouble(
                text.trim().replace(',', '.')
        );
    }

    private String formatNumber(double value) {

        if (value == Math.rint(value)) {
            return String.valueOf((long) value);
        }

        return String.valueOf(value);
    }

    // ========================================
    // ADD COMPONENT MENU
    // ========================================

    private void showAddComponentMenu() {
        if (entity == null) {
            return;
        }

        final String[] components = {
                "ColorRenderer",
                "SpriteRenderer",
                "Rigidbody2D",
                "BoxCollider2D"
        };

        final String[] descriptions = {
                "Отображает объект сплошным цветом.",
                "Позволяет назначить изображение или текстуру.",
                "Добавляет физику: массу, гравитацию и скорость.",
                "Создаёт прямоугольную область столкновений."
        };

        JDialog dialog = new JDialog(
                SwingUtilities.getWindowAncestor(this),
                "Add Component",
                java.awt.Dialog.ModalityType.APPLICATION_MODAL
        );
        dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
        dialog.setSize(380, 410);
        dialog.setMinimumSize(new Dimension(340, 360));
        dialog.setResizable(false);
        dialog.setLocationRelativeTo(this);

        Color background = new Color(30, 30, 33);
        Color cardColor = new Color(42, 42, 46);
        Color accent = new Color(78, 115, 170);

        JPanel root = new JPanel(new BorderLayout(0, 12));
        root.setBackground(background);
        root.setBorder(BorderFactory.createEmptyBorder(16, 16, 16, 16));

        JLabel title = new JLabel("Добавить компонент");
        title.setForeground(Color.WHITE);
        title.setFont(new Font("Arial", Font.BOLD, 16));

        JTextField searchField = new JTextField();
        searchField.setToolTipText("Поиск компонентов");
        searchField.setBackground(cardColor);
        searchField.setForeground(Color.WHITE);
        searchField.setCaretColor(Color.WHITE);
        searchField.setFont(new Font("Arial", Font.PLAIN, 13));
        searchField.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(65, 65, 70)),
                BorderFactory.createEmptyBorder(8, 9, 8, 9)
        ));

        JPanel top = new JPanel(new BorderLayout(0, 10));
        top.setBackground(background);
        top.add(title, BorderLayout.NORTH);
        top.add(searchField, BorderLayout.CENTER);

        DefaultListModel<String> model = new DefaultListModel<>();
        JList<String> list = new JList<>(model);
        list.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        list.setBackground(background);
        list.setForeground(Color.WHITE);
        list.setSelectionBackground(accent);
        list.setSelectionForeground(Color.WHITE);
        list.setFont(new Font("Arial", Font.PLAIN, 13));
        list.setFixedCellHeight(58);
        list.setBorder(BorderFactory.createEmptyBorder(4, 4, 4, 4));

        list.setCellRenderer((jList, value, index, selected, focus) -> {
            JPanel item = new JPanel(new BorderLayout(0, 4));
            item.setBorder(BorderFactory.createEmptyBorder(7, 9, 7, 9));
            item.setBackground(selected ? accent : cardColor);

            JLabel name = new JLabel(value);
            name.setForeground(Color.WHITE);
            name.setFont(new Font("Arial", Font.BOLD, 12));

            int componentIndex = java.util.Arrays.asList(components).indexOf(value);
            JLabel description = new JLabel(
                    componentIndex >= 0 ? descriptions[componentIndex] : ""
            );
            description.setForeground(selected
                    ? new Color(235, 240, 250)
                    : new Color(175, 175, 182));
            description.setFont(new Font("Arial", Font.PLAIN, 10));

            item.add(name, BorderLayout.NORTH);
            item.add(description, BorderLayout.CENTER);
            return item;
        });

        Runnable updateList = () -> {
            String query = searchField.getText().trim()
                    .toLowerCase(java.util.Locale.ROOT);
            String previous = list.getSelectedValue();
            model.clear();

            for (String component : components) {
                if (component.toLowerCase(java.util.Locale.ROOT).contains(query)) {
                    model.addElement(component);
                }
            }

            if (previous != null && model.contains(previous)) {
                list.setSelectedValue(previous, true);
            } else if (!model.isEmpty()) {
                list.setSelectedIndex(0);
            }
        };

        searchField.getDocument().addDocumentListener(
                new javax.swing.event.DocumentListener() {
                    @Override
                    public void insertUpdate(javax.swing.event.DocumentEvent e) {
                        updateList.run();
                    }

                    @Override
                    public void removeUpdate(javax.swing.event.DocumentEvent e) {
                        updateList.run();
                    }

                    @Override
                    public void changedUpdate(javax.swing.event.DocumentEvent e) {
                        updateList.run();
                    }
                }
        );

        JScrollPane scrollPane = new JScrollPane(list);
        scrollPane.setBorder(BorderFactory.createLineBorder(new Color(55, 55, 60)));
        scrollPane.getViewport().setBackground(background);

        JButton addButton = new JButton("Добавить");
        addButton.setFocusPainted(false);
        addButton.setForeground(Color.WHITE);
        addButton.setBackground(accent);
        addButton.setBorder(BorderFactory.createEmptyBorder(8, 16, 8, 16));

        JButton cancelButton = new JButton("Отмена");
        cancelButton.setFocusPainted(false);
        cancelButton.setForeground(Color.WHITE);
        cancelButton.setBackground(cardColor);
        cancelButton.setBorder(BorderFactory.createEmptyBorder(8, 16, 8, 16));

        Runnable addSelected = () -> {
            String choice = list.getSelectedValue();
            if (choice == null) {
                return;
            }
            dialog.dispose();
            addComponentByName(choice);
        };

        addButton.addActionListener(e -> addSelected.run());
        cancelButton.addActionListener(e -> dialog.dispose());
        list.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent e) {
                if (e.getClickCount() == 2 && list.getSelectedValue() != null) {
                    addSelected.run();
                }
            }
        });
        searchField.addActionListener(e -> addSelected.run());

        JPanel buttons = new JPanel(
                new java.awt.FlowLayout(java.awt.FlowLayout.RIGHT, 8, 0)
        );
        buttons.setBackground(background);
        buttons.add(cancelButton);
        buttons.add(addButton);

        root.add(top, BorderLayout.NORTH);
        root.add(scrollPane, BorderLayout.CENTER);
        root.add(buttons, BorderLayout.SOUTH);
        dialog.setContentPane(root);

        updateList.run();
        dialog.setVisible(true);
    }

    private void addComponentByName(String choice) {
        if (entity == null) {
            return;
        }

        if ("ColorRenderer".equals(choice)) {
            if (entity.hasComponent(ColorRenderer.class)) {
                showComponentExists("ColorRenderer");
                return;
            }
            entity.addComponent(new ColorRenderer(entity.getColor()));

        } else if ("SpriteRenderer".equals(choice)) {
            if (entity.hasComponent(SpriteRenderer.class)) {
                showComponentExists("SpriteRenderer");
                return;
            }
            entity.addComponent(new SpriteRenderer());

        } else if ("Rigidbody2D".equals(choice)) {
            if (entity.hasComponent(Rigidbody2D.class)) {
                showComponentExists("Rigidbody2D");
                return;
            }
            entity.addComponent(new Rigidbody2D());

            if (!entity.hasComponent(BoxCollider2D.class)) {
                int answer = JOptionPane.showConfirmDialog(
                        this,
                        "Добавить BoxCollider2D для столкновений?",
                        "Физика",
                        JOptionPane.YES_NO_OPTION
                );
                if (answer == JOptionPane.YES_OPTION) {
                    entity.addComponent(new BoxCollider2D());
                }
            }

        } else if ("BoxCollider2D".equals(choice)) {
            if (entity.hasComponent(BoxCollider2D.class)) {
                showComponentExists("BoxCollider2D");
                return;
            }
            entity.addComponent(new BoxCollider2D());
        }

        refreshComponents();
        repaintGameView();
    }

    private void showComponentExists(String name) {
        JOptionPane.showMessageDialog(
                this,
                "Компонент " + name + " уже добавлен.",
                "Компонент существует",
                JOptionPane.INFORMATION_MESSAGE
        );
    }

    // ========================================
    // COMPONENT LIST
    // ========================================

    private void refreshComponents() {

        componentContainer.removeAll();

        if (entity == null) {

            JLabel emptyLabel = new JLabel(
                    "Select an object first"
            );
            emptyLabel.setForeground(
                    new Color(150, 150, 155)
            );

            componentContainer.add(emptyLabel);

        } else {

            for (Component component : entity.getComponents()) {
                componentContainer.add(
                        createComponentCard(component)
                );
                componentContainer.add(
                        Box.createVerticalStrut(8)
                );
            }
        }

        componentContainer.revalidate();
        componentContainer.repaint();
    }

    private JPanel createComponentCard(
            Component component
    ) {

        JPanel card = new JPanel();
        card.setLayout(
                new BoxLayout(card, BoxLayout.Y_AXIS)
        );
        card.setBackground(new Color(38, 38, 41));
        card.setBorder(
                BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(
                                new Color(55, 55, 59)
                        ),
                        new EmptyBorder(9, 9, 9, 9)
                )
        );
        card.setAlignmentX(LEFT_ALIGNMENT);
        card.setMaximumSize(
                new Dimension(Integer.MAX_VALUE, 380)
        );

        // Component header
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(new Color(45, 45, 48));
        header.setAlignmentX(LEFT_ALIGNMENT);

        JLabel nameLabel = new JLabel(
                component instanceof Transform
                        ? "Transform"
                        : component.getClass().getSimpleName()
        );
        nameLabel.setForeground(Color.WHITE);
        nameLabel.setFont(
                new Font("Arial", Font.BOLD, 12)
        );

        JCheckBox enabledBox = new JCheckBox(
                "Enabled",
                component.isEnabled()
        );
        enabledBox.setOpaque(false);
        enabledBox.setForeground(Color.WHITE);
        enabledBox.addActionListener(e -> {

            component.setEnabled(enabledBox.isSelected());
            repaintGameView();
        });

        header.add(nameLabel, BorderLayout.CENTER);
        header.add(enabledBox, BorderLayout.EAST);

        card.add(header);

        // ColorRenderer settings: solid color is independent from textures.
        if (component instanceof ColorRenderer) {
            ColorRenderer colorRenderer = (ColorRenderer) component;
            card.add(Box.createVerticalStrut(8));

            JCheckBox visibleBox = new JCheckBox("Visible", colorRenderer.isVisible());
            visibleBox.setOpaque(false);
            visibleBox.setForeground(Color.WHITE);
            visibleBox.addActionListener(e -> {
                colorRenderer.setVisible(visibleBox.isSelected());
                repaintGameView();
            });
            card.add(visibleBox);

            JButton colorButton = createButton("Choose Color", colorRenderer.getColor());
            colorButton.addActionListener(e -> {
                Color selectedColor = JColorChooser.showDialog(
                        this, "Color Renderer", colorRenderer.getColor());
                if (selectedColor != null) {
                    colorRenderer.setColor(selectedColor);
                    colorButton.setBackground(selectedColor);
                    if (entity != null) entity.setColor(selectedColor);
                    repaintGameView();
                }
            });
            colorButton.setAlignmentX(LEFT_ALIGNMENT);
            card.add(colorButton);
        }

        // SpriteRenderer settings: images can be dragged from the Files panel
        // directly onto the drop zone or any part of this component card.
        if (component instanceof SpriteRenderer) {
            SpriteRenderer sprite = (SpriteRenderer) component;
            card.add(Box.createVerticalStrut(8));

            JLabel textureLabel = new JLabel(textureDescription(sprite));
            textureLabel.setForeground(new Color(195, 195, 200));
            textureLabel.setToolTipText(sprite.getTexturePath());
            textureLabel.setAlignmentX(LEFT_ALIGNMENT);
            card.add(textureLabel);

            JPanel dropZone = new JPanel(new BorderLayout());
            dropZone.setBackground(new Color(35, 43, 55));
            dropZone.setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createLineBorder(new Color(85, 120, 170)),
                    new EmptyBorder(10, 8, 10, 8)));
            dropZone.setAlignmentX(LEFT_ALIGNMENT);
            dropZone.setMaximumSize(new Dimension(Integer.MAX_VALUE, 58));

            JLabel dropHint = new JLabel("Drop image from Files here", JLabel.CENTER);
            dropHint.setForeground(new Color(155, 190, 240));
            dropZone.add(dropHint, BorderLayout.CENTER);
            card.add(Box.createVerticalStrut(6));
            card.add(dropZone);

            JCheckBox visibleBox = new JCheckBox("Visible", sprite.isVisible());
            visibleBox.setOpaque(false);
            visibleBox.setForeground(Color.WHITE);
            visibleBox.addActionListener(e -> {
                sprite.setVisible(visibleBox.isSelected());
                repaintGameView();
            });
            card.add(visibleBox);

            JButton clearTextureButton = createButton("Clear Texture", new Color(85, 75, 75));
            clearTextureButton.addActionListener(e -> {
                sprite.clearTexture();
                textureLabel.setText(textureDescription(sprite));
                textureLabel.setToolTipText("");
                statusLabel.setForeground(new Color(150, 200, 150));
                statusLabel.setText("Texture cleared");
                repaintGameView();
            });
            card.add(clearTextureButton);

            javax.swing.TransferHandler textureDropHandler = new javax.swing.TransferHandler() {
                @Override
                public boolean canImport(TransferSupport support) {
                    if (!support.isDataFlavorSupported(DataFlavor.javaFileListFlavor)) {
                        return false;
                    }
                    try {
                        @SuppressWarnings("unchecked")
                        List<File> files = (List<File>) support.getTransferable()
                                .getTransferData(DataFlavor.javaFileListFlavor);
                        for (File file : files) {
                            if (file != null && file.isFile() && isImageFile(file)) {
                                return true;
                            }
                        }
                    } catch (Exception ignored) {
                        return false;
                    }
                    return false;
                }

                @Override
                public boolean importData(TransferSupport support) {
                    if (!canImport(support)) return false;
                    try {
                        @SuppressWarnings("unchecked")
                        List<File> files = (List<File>) support.getTransferable()
                                .getTransferData(DataFlavor.javaFileListFlavor);
                        for (File file : files) {
                            if (file != null && file.isFile() && isImageFile(file)) {
                                if (sprite.loadTexture(file.getAbsolutePath())) {
                                    textureLabel.setText(textureDescription(sprite));
                                    textureLabel.setToolTipText(sprite.getTexturePath());
                                    statusLabel.setForeground(new Color(120, 200, 120));
                                    statusLabel.setText("Texture assigned: " + file.getName());
                                    repaintGameView();
                                    return true;
                                }
                            }
                        }
                    } catch (Exception ex) {
                        statusLabel.setForeground(new Color(230, 100, 100));
                        statusLabel.setText("Could not load dropped texture");
                    }
                    return false;
                }
            };

            // Install on the drop zone and its children; this makes the target
            // forgiving even when the cursor is over the label inside the zone.
            installTextureDropHandler(dropZone, textureDropHandler);
            installTextureDropHandler(card, textureDropHandler);
        }

        // Rigidbody2D settings
        if (component instanceof Rigidbody2D) {
            Rigidbody2D body = (Rigidbody2D) component;
            card.add(Box.createVerticalStrut(8));

            JLabel note = new JLabel("Physics body");
            note.setForeground(new Color(180, 180, 185));
            note.setAlignmentX(LEFT_ALIGNMENT);
            card.add(note);

            JComboBox<Rigidbody2D.BodyType> typeBox = new JComboBox<>(Rigidbody2D.BodyType.values());
            typeBox.setSelectedItem(body.getBodyType());
            typeBox.addActionListener(e -> {
                body.setBodyType((Rigidbody2D.BodyType) typeBox.getSelectedItem());
                repaintGameView();
            });
            typeBox.setMaximumSize(new Dimension(Integer.MAX_VALUE, 28));
            typeBox.setAlignmentX(LEFT_ALIGNMENT);
            card.add(createRow("Body Type", typeBox));

            JTextField massField = createField();
            massField.setText(formatNumber(body.getMass()));
            massField.addActionListener(e -> {
                try {
                    body.setMass(parseNumber(massField.getText()));
                    massField.setText(formatNumber(body.getMass()));
                    statusLabel.setText("Mass updated");
                } catch (NumberFormatException ex) {
                    statusLabel.setText("Invalid mass value");
                }
            });
            card.add(createRow("Mass", massField));

            JTextField gravityField = createField();
            gravityField.setText(formatNumber(body.getGravityScale()));
            gravityField.addActionListener(e -> {
                try {
                    body.setGravityScale(parseNumber(gravityField.getText()));
                    gravityField.setText(formatNumber(body.getGravityScale()));
                    statusLabel.setText("Gravity scale updated");
                } catch (NumberFormatException ex) {
                    statusLabel.setText("Invalid gravity scale");
                }
            });
            card.add(createRow("Gravity Scale", gravityField));

            JCheckBox gravityBox = new JCheckBox("Use Gravity", body.isUseGravity());
            gravityBox.setOpaque(false);
            gravityBox.setForeground(Color.WHITE);
            gravityBox.addActionListener(e -> body.setUseGravity(gravityBox.isSelected()));
            card.add(gravityBox);

            JTextField velocityXField = createField();
            JTextField velocityYField = createField();
            velocityXField.setText(formatNumber(body.getVelocityX()));
            velocityYField.setText(formatNumber(body.getVelocityY()));
            java.awt.event.ActionListener velocityApply = e -> {
                try {
                    body.setVelocity(parseNumber(velocityXField.getText()), parseNumber(velocityYField.getText()));
                    velocityXField.setText(formatNumber(body.getVelocityX()));
                    velocityYField.setText(formatNumber(body.getVelocityY()));
                    statusLabel.setText("Velocity updated");
                } catch (NumberFormatException ex) {
                    statusLabel.setText("Invalid velocity value");
                }
            };
            velocityXField.addActionListener(velocityApply);
            velocityYField.addActionListener(velocityApply);
            card.add(createRow("Velocity X", velocityXField));
            card.add(createRow("Velocity Y", velocityYField));
        }

        // BoxCollider2D settings
        if (component instanceof BoxCollider2D) {
            BoxCollider2D collider = (BoxCollider2D) component;
            card.add(Box.createVerticalStrut(8));
            JLabel shapeLabel = new JLabel("Rectangle collider (object size)");
            shapeLabel.setForeground(new Color(180, 180, 185));
            shapeLabel.setAlignmentX(LEFT_ALIGNMENT);
            card.add(shapeLabel);

            JTextField offsetXField = createField();
            JTextField offsetYField = createField();
            offsetXField.setText(formatNumber(collider.getOffsetX()));
            offsetYField.setText(formatNumber(collider.getOffsetY()));
            java.awt.event.ActionListener offsetApply = e -> {
                try {
                    collider.setOffsetX(parseNumber(offsetXField.getText()));
                    collider.setOffsetY(parseNumber(offsetYField.getText()));
                    offsetXField.setText(formatNumber(collider.getOffsetX()));
                    offsetYField.setText(formatNumber(collider.getOffsetY()));
                    statusLabel.setText("Collider offsets updated");
                } catch (NumberFormatException ex) {
                    statusLabel.setText("Invalid collider offset");
                }
            };
            offsetXField.addActionListener(offsetApply);
            offsetYField.addActionListener(offsetApply);
            card.add(createRow("Offset X", offsetXField));
            card.add(createRow("Offset Y", offsetYField));

            JCheckBox triggerBox = new JCheckBox("Is Trigger (no solid collision)", collider.isTrigger());
            triggerBox.setOpaque(false);
            triggerBox.setForeground(Color.WHITE);
            triggerBox.addActionListener(e -> collider.setTrigger(triggerBox.isSelected()));
            card.add(triggerBox);
        }

        // Remove component
        if (!(component instanceof Transform)) {

            card.add(Box.createVerticalStrut(8));

            JButton removeButton = createButton(
                    "Remove Component",
                    new Color(130, 55, 55)
            );

            removeButton.addActionListener(e -> {

                int answer = JOptionPane.showConfirmDialog(
                        this,
                        "Remove " + component.getClass().getSimpleName()
                                + " from " + entity.getName() + "?",
                        "Remove Component",
                        JOptionPane.YES_NO_OPTION
                );

                if (answer == JOptionPane.YES_OPTION) {

                    entity.removeComponent(component);
                    refreshComponents();
                    repaintGameView();
                }
            });

            card.add(removeButton);
        }

        return card;
    }

    private String textureDescription(SpriteRenderer sprite) {
        if (sprite == null || sprite.getTexturePath() == null
                || sprite.getTexturePath().isEmpty()) {
            return "Texture: (none)";
        }
        return "Texture: " + new File(sprite.getTexturePath()).getName();
    }

    private boolean isImageFile(File file) {
        String name = file.getName().toLowerCase(java.util.Locale.ROOT);
        return name.endsWith(".png") || name.endsWith(".jpg") || name.endsWith(".jpeg")
                || name.endsWith(".gif") || name.endsWith(".bmp");
    }

    private void installTextureDropHandler(java.awt.Component component,
                                           javax.swing.TransferHandler handler) {
        if (component instanceof javax.swing.JComponent) {
            ((javax.swing.JComponent) component).setTransferHandler(handler);
        }
        if (component instanceof java.awt.Container) {
            for (java.awt.Component child : ((java.awt.Container) component).getComponents()) {
                installTextureDropHandler(child, handler);
            }
        }
    }

    // ========================================
    // GAME VIEW
    // ========================================

    private void repaintGameView() {

        java.awt.Window window =
                SwingUtilities.getWindowAncestor(this);

        if (window instanceof Editor) {

            Editor editor = (Editor) window;

            GameViewPanel gameView =
                    editor.getGameView();

            if (gameView != null) {
                gameView.repaint();
            }
        }
    }

    public Entity getEntity() {
        return entity;
    }
}