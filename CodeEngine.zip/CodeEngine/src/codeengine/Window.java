package codeengine;

import javax.swing.JFrame;

public class Window {

    private final JFrame frame;
    private final GamePanel panel;

    public Window(
            String title,
            int width,
            int height,
            Renderer2D renderer
    ) {

        frame = new JFrame(title);

        panel = new GamePanel(renderer);

        frame.setContentPane(panel);

        frame.setSize(width, height);

        frame.setDefaultCloseOperation(
                JFrame.EXIT_ON_CLOSE
        );

        frame.setLocationRelativeTo(null);

        frame.setResizable(false);

        frame.setVisible(true);

        panel.requestFocusInWindow();
        panel.addKeyListener(Input.getInstance());
        panel.addMouseListener(Mouse.getInstance());
panel.addMouseMotionListener(Mouse.getInstance());
    }

    public JFrame getFrame() {
        return frame;
    }

    public GamePanel getPanel() {
        return panel;
    }
}