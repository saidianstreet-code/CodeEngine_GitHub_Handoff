
package codeengine;

/**
 * Базовый класс пользовательских Java-скриптов.
 */
public abstract class ScriptComponent extends Component {

    private boolean started = false;

    /**
     * Вызывается один раз перед первым обновлением.
     */
    protected void start() {
    }

    /**
     * Вызывается каждый кадр, пока компонент включён.
     */
    protected void onUpdate(double deltaTime) {
    }

    /**
     * Вызывается при сбросе или остановке скрипта.
     */
    protected void onDestroy() {
    }

    @Override
    public final void update(double deltaTime) {
        if (!isEnabled()) {
            return;
        }

        if (!started) {
            started = true;
            start();
        }

        onUpdate(deltaTime);
    }

    /**
     * Сбрасывает состояние скрипта.
     */
    public final void resetScript() {
        if (started) {
            try {
                onDestroy();
            } finally {
                started = false;
            }
        }
    }

    public final boolean hasStarted() {
        return started;
    }
}
