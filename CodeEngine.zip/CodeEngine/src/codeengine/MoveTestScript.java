
package codeengine;

public class MoveTestScript extends ScriptComponent {

    private double speed = 100.0;

    @Override
    protected void start() {
        System.out.println(
            "Скрипт запущен на объекте: " + getEntity().getName()
        );
    }

    @Override
    protected void onUpdate(double deltaTime) {
        Entity entity = getEntity();

        if (entity != null) {
            entity.move(speed * deltaTime, 0);
        }
    }

    public double getSpeed() {
        return speed;
    }

    public void setSpeed(double speed) {
        this.speed = Math.max(0, speed);
    }
}
