package codeengine;

public class Transform extends Component {

    private double x;
    private double y;

    private double width = 50;
    private double height = 50;

    public Transform() {
    }

    public Transform(double x, double y) {
        this.x = x;
        this.y = y;
    }

    public double getX() {
        return x;
    }

    public double getY() {
        return y;
    }

    public double getWidth() {
        return width;
    }

    public double getHeight() {
        return height;
    }

    public void setPosition(
            double x,
            double y
    ) {
        this.x = x;
        this.y = y;
    }

    public void move(
            double dx,
            double dy
    ) {
        this.x += dx;
        this.y += dy;
    }

    public void setSize(
            double width,
            double height
    ) {
        this.width = width;
        this.height = height;
    }
}