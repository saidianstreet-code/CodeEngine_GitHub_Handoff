package codeengine;

import java.awt.Color;

/** Renders a solid-color rectangle for an Entity. */
public class ColorRenderer extends Component {
    private Color color = Color.WHITE;
    private boolean visible = true;

    public ColorRenderer() { }

    public ColorRenderer(Color color) {
        setColor(color);
    }

    public Color getColor() { return color; }

    public void setColor(Color color) {
        if (color != null) this.color = color;
    }

    public boolean isVisible() { return visible; }

    public void setVisible(boolean visible) { this.visible = visible; }

    public void render(Renderer2D renderer) {
        if (!isEnabled() || !visible || renderer == null) return;
        Entity entity = getEntity();
        if (entity == null || !entity.isVisible()) return;
        renderer.drawRect((int) entity.getX(), (int) entity.getY(),
                (int) entity.getWidth(), (int) entity.getHeight(), color);
    }

    @Override
    public String toString() { return "ColorRenderer"; }
}
