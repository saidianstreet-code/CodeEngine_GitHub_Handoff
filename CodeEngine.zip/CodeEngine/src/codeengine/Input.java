package codeengine;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

public class Input implements KeyListener {

    private static final boolean[] keys = new boolean[256];

    private static final boolean[] pressed = new boolean[256];

    private static final boolean[] released = new boolean[256];

    private static final Input instance = new Input();

    private Input() {
    }

    public static Input getInstance() {
        return instance;
    }

    @Override
    public void keyPressed(KeyEvent e) {

        int code = e.getKeyCode();

        if (code >= 0 && code < keys.length) {

            if (!keys[code]) {
                pressed[code] = true;
            }

            keys[code] = true;
        }
    }

    @Override
    public void keyReleased(KeyEvent e) {

        int code = e.getKeyCode();

        if (code >= 0 && code < keys.length) {

            keys[code] = false;
            released[code] = true;
        }
    }

    @Override
    public void keyTyped(KeyEvent e) {
    }

    /**
     * Проверяет, удерживается ли клавиша.
     */
    public static boolean isKeyDown(Key key) {

        int code = getKeyCode(key);

        return code >= 0
                && code < keys.length
                && keys[code];
    }

    /**
     * Проверяет нажатие клавиши в текущем кадре.
     */
    public static boolean isKeyPressed(Key key) {

        int code = getKeyCode(key);

        return code >= 0
                && code < pressed.length
                && pressed[code];
    }

    /**
     * Проверяет отпускание клавиши в текущем кадре.
     */
    public static boolean isKeyReleased(Key key) {

        int code = getKeyCode(key);

        return code >= 0
                && code < released.length
                && released[code];
    }

    /**
     * Очищает состояния pressed/released.
     */
    public static void update() {

        for (int i = 0; i < pressed.length; i++) {
            pressed[i] = false;
            released[i] = false;
        }
    }

    private static int getKeyCode(Key key) {

        switch (key) {

            case A: return KeyEvent.VK_A;
            case B: return KeyEvent.VK_B;
            case C: return KeyEvent.VK_C;
            case D: return KeyEvent.VK_D;
            case E: return KeyEvent.VK_E;
            case F: return KeyEvent.VK_F;
            case G: return KeyEvent.VK_G;
            case H: return KeyEvent.VK_H;
            case I: return KeyEvent.VK_I;
            case J: return KeyEvent.VK_J;
            case K: return KeyEvent.VK_K;
            case L: return KeyEvent.VK_L;
            case M: return KeyEvent.VK_M;
            case N: return KeyEvent.VK_N;
            case O: return KeyEvent.VK_O;
            case P: return KeyEvent.VK_P;
            case Q: return KeyEvent.VK_Q;
            case R: return KeyEvent.VK_R;
            case S: return KeyEvent.VK_S;
            case T: return KeyEvent.VK_T;
            case U: return KeyEvent.VK_U;
            case V: return KeyEvent.VK_V;
            case W: return KeyEvent.VK_W;
            case X: return KeyEvent.VK_X;
            case Y: return KeyEvent.VK_Y;
            case Z: return KeyEvent.VK_Z;

            case UP: return KeyEvent.VK_UP;
            case DOWN: return KeyEvent.VK_DOWN;
            case LEFT: return KeyEvent.VK_LEFT;
            case RIGHT: return KeyEvent.VK_RIGHT;

            case SPACE: return KeyEvent.VK_SPACE;
            case SHIFT: return KeyEvent.VK_SHIFT;
            case CTRL: return KeyEvent.VK_CONTROL;
            case ALT: return KeyEvent.VK_ALT;

            case ENTER: return KeyEvent.VK_ENTER;
            case ESCAPE: return KeyEvent.VK_ESCAPE;
            case TAB: return KeyEvent.VK_TAB;

            case F1: return KeyEvent.VK_F1;
            case F2: return KeyEvent.VK_F2;
            case F3: return KeyEvent.VK_F3;
            case F4: return KeyEvent.VK_F4;
            case F5: return KeyEvent.VK_F5;
            case F6: return KeyEvent.VK_F6;
            case F7: return KeyEvent.VK_F7;
            case F8: return KeyEvent.VK_F8;
            case F9: return KeyEvent.VK_F9;
            case F10: return KeyEvent.VK_F10;
            case F11: return KeyEvent.VK_F11;
            case F12: return KeyEvent.VK_F12;

            default:
                return -1;
        }
    }
}