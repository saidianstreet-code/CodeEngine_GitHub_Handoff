
package codeengine;

public abstract class Game {

    private boolean running = false;
    private boolean playMode = false;

    private long lastTime;
    private double deltaTime;

    private int fps;
    private int frames;
    private long fpsTimer;

    private Window window;
    private Renderer2D renderer;
    private Scene scene;
    private Editor editor;

    public abstract void create();

    public abstract void update(double deltaTime);

    public void onSceneChanged() {
    }

    /**
     * Регистрирует редактор, в котором будет запускаться игра.
     */
    public void setEditor(Editor editor) {
        this.editor = editor;
    }

    public Editor getEditor() {
        return editor;
    }

    public void startEngine() {
        renderer = new Renderer2D();

        window = new Window(
                "CodeEngine",
                1280,
                720,
                renderer
        );

        scene = new Scene();
        window.getPanel().setScene(scene);

        // Создаём игровую сцену и редактор.
        create();

        /*
         * Если игра подключила Editor, используем его
         * Viewport вместо отдельного игрового окна.
         */
        if (editor != null && window != null) {
            window.getFrame().setVisible(false);
        }

        running = true;
        lastTime = System.nanoTime();
        fpsTimer = System.currentTimeMillis();

        while (running) {
            long currentTime = System.nanoTime();

            deltaTime =
                    (currentTime - lastTime)
                            / 1_000_000_000.0;

            lastTime = currentTime;

            if (playMode) {
                update(deltaTime);

                if (scene != null) {
                    scene.update(deltaTime);
                }
            }

            // Обновляем отображение редактора.
            if (editor != null) {
                if (editor.getGameView() != null) {
                    editor.getGameView().repaint();
                }
            } else if (window != null
                    && window.getPanel() != null) {
                // Обычный режим без редактора.
                window.getPanel().repaint();
            }

            frames++;

            if (System.currentTimeMillis() - fpsTimer >= 1000) {
                fps = frames;
                frames = 0;
                fpsTimer = System.currentTimeMillis();

                if (editor == null && window != null) {
                    window.getFrame().setTitle(
                            "CodeEngine | FPS: " + fps
                    );
                }
            }

            long frameTime =
                    System.nanoTime() - currentTime;

            long sleepTime = 16_666_666L - frameTime;

            if (sleepTime > 0) {
                try {
                    Thread.sleep(
                            sleepTime / 1_000_000L,
                            (int) (sleepTime % 1_000_000L)
                    );
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                    stop();
                }
            }

            Input.update();
            Mouse.update();
        }
    }

    public void stop() {
        running = false;
    }

    public boolean isRunning() {
        return running;
    }

    public boolean isPlayMode() {
        return playMode;
    }

    public void setPlayMode(boolean playMode) {
        this.playMode = playMode;
    }

    public double getDeltaTime() {
        return deltaTime;
    }

    public int getFPS() {
        return fps;
    }

    public Window getWindow() {
        return window;
    }

    public Renderer2D getRenderer() {
        return renderer;
    }

    public Scene getScene() {
        return scene;
    }

    public void setScene(Scene scene) {
        this.scene = scene;

        if (window != null && window.getPanel() != null) {
            window.getPanel().setScene(scene);
        }

        if (editor != null) {
            editor.getGameView().setScene(scene);
            editor.getGameView().repaint();
        }

        onSceneChanged();
    }
}
