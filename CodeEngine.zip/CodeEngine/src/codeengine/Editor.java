
package codeengine;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.io.File;

public class Editor extends JFrame {

    private final HierarchyPanel hierarchyPanel;
    private final InspectorPanel inspectorPanel;
    private final FilePanel filePanel;
    private final GameViewPanel gameView;

    private final JButton playButton;
    private final JButton stopButton;
    private final JButton saveButton;

    private Scene scene;
    private Scene editorScene;
    private Scene runtimeScene;

    private Game game;
    private boolean playing = false;

    public Editor() {
        super("CodeEngine Editor");

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1200, 750);
        setMinimumSize(new Dimension(900, 600));
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        // ========================================
        // TOP BAR
        // ========================================

        JPanel topBar = new JPanel(new BorderLayout());
        topBar.setBackground(new Color(40, 40, 43));

        JPanel leftBar = new JPanel(new BorderLayout());
        leftBar.setBackground(new Color(40, 40, 43));

        JLabel title = new JLabel("  CodeEngine");
        title.setForeground(Color.WHITE);
        title.setFont(new Font("Arial", Font.BOLD, 16));

        leftBar.add(title, BorderLayout.CENTER);
        topBar.add(leftBar, BorderLayout.WEST);

        JPanel controls = new JPanel();
        controls.setBackground(new Color(40, 40, 43));

        playButton = createButton("▶ Play");
        stopButton = createButton("■ Stop");
        saveButton = createButton("Save");

        stopButton.setEnabled(false);

        controls.add(playButton);
        controls.add(stopButton);
        controls.add(saveButton);

        topBar.add(controls, BorderLayout.CENTER);
        add(topBar, BorderLayout.NORTH);

        // ========================================
        // HIERARCHY
        // ========================================

        hierarchyPanel = new HierarchyPanel();
        add(hierarchyPanel, BorderLayout.WEST);

        // ========================================
        // INSPECTOR
        // ========================================

        inspectorPanel = new InspectorPanel();
        add(inspectorPanel, BorderLayout.EAST);

        // ========================================
        // GAME VIEW / VIEWPORT
        // ========================================

        gameView = new GameViewPanel();
        gameView.setBackground(new Color(25, 25, 28));
        gameView.setFocusable(true);
        gameView.setHierarchyPanel(hierarchyPanel);

        add(gameView, BorderLayout.CENTER);

        // ========================================
        // FILE PANEL
        // ========================================

        filePanel = new FilePanel();

        File projectDirectory =
                new File(System.getProperty("user.dir"));

        filePanel.setProjectDirectory(projectDirectory);

        filePanel.setTextureApplyHandler(image -> {
            if (playing) {
                JOptionPane.showMessageDialog(
                        this,
                        "Остановите игру перед изменением объектов.",
                        "CodeEngine",
                        JOptionPane.INFORMATION_MESSAGE
                );
                return;
            }

            Entity selected =
                    hierarchyPanel.getList().getSelectedValue();

            if (selected == null) {
                JOptionPane.showMessageDialog(
                        this,
                        "Сначала выберите Entity в Hierarchy.",
                        "CodeEngine",
                        JOptionPane.INFORMATION_MESSAGE
                );
                return;
            }

            SpriteRenderer sprite =
                    selected.getComponent(SpriteRenderer.class);

            if (sprite == null) {
                sprite = new SpriteRenderer();
                selected.addComponent(sprite);
            }

            if (sprite.loadTexture(image.getAbsolutePath())) {
                inspectorPanel.setEntity(selected);
                gameView.setSelectedEntity(selected);
                gameView.repaint();

                System.out.println(
                        "[CodeEngine] Texture assigned: "
                                + image.getName()
                );
            } else {
                JOptionPane.showMessageDialog(
                        this,
                        "Не удалось загрузить изображение:\n"
                                + image.getAbsolutePath(),
                        "CodeEngine",
                        JOptionPane.ERROR_MESSAGE
                );
            }
        });

        add(filePanel, BorderLayout.SOUTH);

        // ========================================
        // ENTITY SELECTION
        // ========================================

        hierarchyPanel.getList().addListSelectionListener(e -> {
            if (e.getValueIsAdjusting()) {
                return;
            }

            Entity selected =
                    hierarchyPanel.getList().getSelectedValue();

            inspectorPanel.setEntity(selected);
            gameView.setSelectedEntity(selected);
        });

        // ========================================
        // BUTTONS
        // ========================================

        playButton.addActionListener(e -> startPlayMode());
        stopButton.addActionListener(e -> stopPlayMode());
        saveButton.addActionListener(e -> saveScene());
    }

    // ========================================
    // BUTTON CREATION
    // ========================================

    private JButton createButton(String text) {
        JButton button = new JButton(text);

        button.setFocusPainted(false);
        button.setForeground(Color.WHITE);
        button.setBackground(new Color(60, 60, 63));

        return button;
    }

    // ========================================
    // CONNECT GAME
    // ========================================

    public void setGame(Game game) {
        this.game = game;

        if (game != null) {
            game.setEditor(this);

            if (game.getScene() != null) {
                setScene(game.getScene());
            }
        }
    }

    // ========================================
    // PLAY MODE
    // ========================================

    private void startPlayMode() {
        if (playing) {
            return;
        }

        if (game == null) {
            System.out.println(
                    "[CodeEngine] Game не установлен."
            );
            return;
        }

        if (scene == null) {
            System.out.println(
                    "[CodeEngine] Нет сцены."
            );
            return;
        }

        // Сохраняем оригинальную сцену редактора.
        editorScene = scene;

        // Создаём отдельную копию для запуска игры.
        runtimeScene = editorScene.copy();

        // Передаём копию игре.
        game.setScene(runtimeScene);

        // Показываем копию в Viewport и Hierarchy.
        setScene(runtimeScene);

        game.setPlayMode(true);

        playing = true;

        playButton.setEnabled(false);
        stopButton.setEnabled(true);

        // Передаём клавиатурный фокус игровому Viewport.
        gameView.setFocusable(true);

        requestViewportFocus();

        System.out.println("[CodeEngine] PLAY");
        System.out.println(
                "[CodeEngine] Runtime Scene создана."
        );
        System.out.println(
                "[CodeEngine] Игра запущена в редакторе."
        );
    }

    private void requestViewportFocus() {
        javax.swing.SwingUtilities.invokeLater(() -> {
            if (gameView.isShowing()) {
                gameView.requestFocusInWindow();
            }
        });
    }

    // ========================================
    // STOP MODE
    // ========================================

    private void stopPlayMode() {
        if (!playing) {
            return;
        }

        // Останавливаем игровую логику.
        game.setPlayMode(false);

        // Возвращаем оригинальную сцену.
        game.setScene(editorScene);
        setScene(editorScene);

        // Удаляем временную runtime-сцену.
        runtimeScene = null;
        editorScene = null;

        // Сбрасываем выделение.
        inspectorPanel.setEntity(null);
        gameView.setSelectedEntity(null);
        hierarchyPanel.clearSelection();

        playing = false;

        playButton.setEnabled(true);
        stopButton.setEnabled(false);

        System.out.println("[CodeEngine] STOP");
        System.out.println(
                "[CodeEngine] Runtime Scene удалена."
        );
        System.out.println(
                "[CodeEngine] Сцена редактора восстановлена."
        );
    }

    // ========================================
    // SAVE SCENE
    // ========================================

    private void saveScene() {
        System.out.println("[CodeEngine] Сохранение сцены...");

        if (scene == null) {
            System.out.println("[CodeEngine] Нет сцены.");
            return;
        }

        if (playing) {
            System.out.println(
                    "[CodeEngine] Нельзя сохранять runtime-сцену."
            );
            return;
        }

        System.out.println(
                "[CodeEngine] Сохранено объектов: "
                        + scene.size()
        );

        System.out.println(
                "[CodeEngine] Примечание: пока выводится "
                        + "информация, файл сцены ещё не создаётся."
        );
    }

    // ========================================
    // GETTERS
    // ========================================

    public boolean isPlaying() {
        return playing;
    }

    public void setScene(Scene scene) {
        this.scene = scene;

        hierarchyPanel.setScene(scene);
        gameView.setScene(scene);

        gameView.repaint();
    }

    public Scene getScene() {
        return scene;
    }

    public HierarchyPanel getHierarchyPanel() {
        return hierarchyPanel;
    }

    public InspectorPanel getInspectorPanel() {
        return inspectorPanel;
    }

    public FilePanel getFilePanel() {
        return filePanel;
    }

    public GameViewPanel getGameView() {
        return gameView;
    }

    public void showEditor() {
        setVisible(true);
        requestViewportFocus();
    }
}
