
package codeengine;

import java.util.ArrayList;
import java.util.List;

public class Scene {

    private final List<Entity> entities = new ArrayList<>();

    public void add(Entity entity) {
        if (entity != null && !entities.contains(entity)) {
            entities.add(entity);
        }
    }

    public void remove(Entity entity) {
        entities.remove(entity);
    }

    public void update(double deltaTime) {
        double safeDelta = Math.max(0, Math.min(deltaTime, 0.25));

        for (Entity entity : new ArrayList<>(entities)) {
            if (entity != null) {
                entity.update(safeDelta);
            }
        }

        Physics2D.update(this, safeDelta);
    }

    public void render(Renderer2D renderer) {
        for (Entity entity : new ArrayList<>(entities)) {
            if (entity != null) {
                entity.render(renderer);
            }
        }
    }

    public void clear() {
        entities.clear();
    }

    public int size() {
        return entities.size();
    }

    public List<Entity> getEntities() {
        return entities;
    }

    /**
     * Создаёт независимую копию сцены.
     * Поддерживаемые компоненты и известные скрипты
     * создаются заново для копии.
     */
    public Scene copy() {
        Scene copy = new Scene();

        for (Entity original : entities) {
            if (original == null) {
                continue;
            }

            Entity clone = new Entity(original.getName());

            clone.setPosition(original.getX(), original.getY());
            clone.setSize(original.getWidth(), original.getHeight());
            clone.setColor(original.getColor());
            clone.setVisible(original.isVisible());
            clone.setActive(original.isActive());

            // ColorRenderer
            ColorRenderer originalColor =
                    original.getComponent(ColorRenderer.class);

            if (originalColor != null) {
                ColorRenderer c =
                        new ColorRenderer(originalColor.getColor());

                c.setVisible(originalColor.isVisible());
                c.setEnabled(originalColor.isEnabled());
                clone.addComponent(c);
            }

            // SpriteRenderer
            SpriteRenderer originalSprite =
                    original.getComponent(SpriteRenderer.class);

            if (originalSprite != null) {
                SpriteRenderer s =
                        new SpriteRenderer(originalSprite.getColor());

                s.setVisible(originalSprite.isVisible());
                s.setEnabled(originalSprite.isEnabled());

                String path = originalSprite.getTexturePath();

                if (path != null && !path.trim().isEmpty()
                        && !s.loadTexture(path)) {
                    System.err.println(
                            "CodeEngine: Не удалось скопировать текстуру объекта '"
                                    + original.getName() + "': " + path
                    );
                }

                clone.addComponent(s);
            }

            // Rigidbody2D
            Rigidbody2D originalBody =
                    original.getComponent(Rigidbody2D.class);

            if (originalBody != null) {
                Rigidbody2D b = new Rigidbody2D();

                b.setBodyType(originalBody.getBodyType());
                b.setMass(originalBody.getMass());
                b.setGravityScale(originalBody.getGravityScale());
                b.setUseGravity(originalBody.isUseGravity());
                b.setVelocity(
                        originalBody.getVelocityX(),
                        originalBody.getVelocityY()
                );
                b.setEnabled(originalBody.isEnabled());

                clone.addComponent(b);
            }

            // BoxCollider2D
            BoxCollider2D originalCollider =
                    original.getComponent(BoxCollider2D.class);

            if (originalCollider != null) {
                BoxCollider2D c = new BoxCollider2D();

                c.setOffsetX(originalCollider.getOffsetX());
                c.setOffsetY(originalCollider.getOffsetY());
                c.setTrigger(originalCollider.isTrigger());
                c.setEnabled(originalCollider.isEnabled());

                clone.addComponent(c);
            }

            // PlayerController
            PlayerController originalController =
                    original.getComponent(PlayerController.class);

            if (originalController != null) {
                PlayerController controller = new PlayerController();

                controller.setSpeed(originalController.getSpeed());
                controller.setEnabled(originalController.isEnabled());

                clone.addComponent(controller);
            }

            // MoveTestScript
            MoveTestScript originalTest =
                    original.getComponent(MoveTestScript.class);

            if (originalTest != null) {
                MoveTestScript test = new MoveTestScript();

                test.setSpeed(originalTest.getSpeed());
                test.setEnabled(originalTest.isEnabled());

                clone.addComponent(test);
            }

            copy.add(clone);
        }

        return copy;
    }

    public Entity find(String name) {
        if (name == null) {
            return null;
        }

        for (Entity entity : entities) {
            if (entity != null && name.equals(entity.getName())) {
                return entity;
            }
        }

        return null;
    }
}
