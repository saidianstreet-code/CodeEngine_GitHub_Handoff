
package codeengine;

/**
 * Пример пользовательского скрипта:
 * управление объектом с помощью WASD или стрелок.
 */
public class PlayerController extends ScriptComponent {

    private double speed = 200.0;

    @Override
    protected void start() {
        System.out.println("PlayerController запущен!");
    }

    @Override
    protected void onUpdate(double deltaTime) {
        Entity entity = getEntity();

        if (entity == null) {
            return;
        }

        Transform transform = entity.getTransform();

        double dx = 0;
        double dy = 0;

        if (Input.isKeyDown(Key.A) || Input.isKeyDown(Key.LEFT)) {
            dx -= 1;
        }

        if (Input.isKeyDown(Key.D) || Input.isKeyDown(Key.RIGHT)) {
            dx += 1;
        }

        if (Input.isKeyDown(Key.W) || Input.isKeyDown(Key.UP)) {
            dy -= 1;
        }

        if (Input.isKeyDown(Key.S) || Input.isKeyDown(Key.DOWN)) {
            dy += 1;
        }

        // Нормализация: движение по диагонали
        // не должно быть быстрее обычного.
        if (dx != 0 || dy != 0) {
            double length = Math.sqrt(dx * dx + dy * dy);

            dx /= length;
            dy /= length;

            transform.move(
                dx * speed * deltaTime,
                dy * speed * deltaTime
            );
        }
    }

    public double getSpeed() {
        return speed;
    }

    public void setSpeed(double speed) {
        this.speed = Math.max(0, speed);
    }
}
